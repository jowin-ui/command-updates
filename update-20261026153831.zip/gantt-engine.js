/* gantt-engine.js — the Celestial Gantt. One engine, used by the desktop app AND the phone app.
   GanttEngine.create(rootElement, { adapter, projectId, prefix }) */
(function (global) {
"use strict";
const DAY = 86400000, HDR = 58;
const MON = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
const PALETTE = [
  { dark: "#0ea5d6", light: "#a5e4f8" }, { dark: "#2fb34a", light: "#ade9b8" }, { dark: "#7d8491", light: "#d5d8de" },
  { dark: "#f0701a", light: "#ffc8a0" }, { dark: "#c9a227", light: "#f1df9e" }, { dark: "#8e5bd1", light: "#dac8f3" },
];
const TYPE_NAMES = { FS: "Finish → Start", SS: "Start → Start", FF: "Finish → Finish", SF: "Start → Finish" };
const COLS = [
  { k: "n", t: "#", w: 36, fixed: true },
  { k: "name", t: "Task name", flex: true, fixed: true },
  { k: "wbs", t: "WBS", w: 46 },
  { k: "start", t: "Start", w: 92 },
  { k: "end", t: "Finish", w: 92 },
  { k: "dur", t: "Dur", w: 46, right: true },
  { k: "pct", t: "%", w: 46, right: true },
  { k: "pred", t: "Pred", w: 78, right: true },
  { k: "res", t: "Resource", w: 110 },
  { k: "status", t: "Status", w: 92 },
];
const OPTIONAL_COLS = ["wbs", "start", "end", "dur", "pct", "pred", "res", "status"];

const pad = (n) => String(n).padStart(2, "0");
function parseDate(s) { const [y, m, d] = s.split("-").map(Number); return new Date(Date.UTC(y, m - 1, d)); }
function fmt(d) { return d.getUTCFullYear() + "-" + pad(d.getUTCMonth() + 1) + "-" + pad(d.getUTCDate()); }
function addDays(s, n) { return fmt(new Date(parseDate(s).getTime() + n * DAY)); }
function diffDays(a, b) { return Math.round((parseDate(a) - parseDate(b)) / DAY); }
function todayStr() { const d = new Date(); return d.getFullYear() + "-" + pad(d.getMonth() + 1) + "-" + pad(d.getDate()); }
function showDate(s) { if (!s) return ""; const [y, m, d] = s.split("-"); return (+m) + "/" + (+d) + "/" + y; }
function shortDate(s) { const dt = parseDate(s); return MON[dt.getUTCMonth()] + " " + dt.getUTCDate(); }
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

const CSS = `
.cg{--gold:#d5af34;--black:#0a0a0a;--ink:#1c1a16;--muted:#8a8578;--border:#e5e0d3;--row:34px;--hdr:58px;--leftW:620px;--cols:36px minmax(60px,1fr) 46px 92px 92px 46px 46px 78px;display:flex;flex-direction:column;height:100%;min-height:0;font-family:Arial,sans-serif;font-size:13px;color:var(--ink);background:#fff;position:relative;-webkit-tap-highlight-color:transparent}
.cg *{box-sizing:border-box}
.cg.cg-full{position:fixed;inset:0;z-index:900;height:auto!important;width:auto!important;margin:0!important;border:0!important;border-radius:0!important}
.cg-tabs{display:flex;align-items:flex-end;gap:2px;padding:6px 14px 0;background:#faf9f5;border-bottom:1px solid var(--border);flex-shrink:0}
.cg-tab{border:1px solid var(--border);border-bottom:none;background:#efece2;padding:7px 18px;border-radius:6px 6px 0 0;font-size:12.5px;font-weight:700;cursor:pointer;color:#6b6656;font-family:inherit}
.cg-tab.on{background:#fff;color:var(--ink);margin-bottom:-1px;box-shadow:inset 0 3px 0 var(--gold)}
.cg-save{margin-left:auto;font-size:11.5px;color:var(--muted);padding-bottom:7px}
.cg-sync{border:1px solid var(--border);background:#fff;border-radius:12px;padding:3px 10px;font-size:11.5px;cursor:pointer;margin:0 0 6px 10px;color:#55503f;font-family:inherit;white-space:nowrap}
.cg-sync.off{background:#fff3e0;border-color:#f0c987;color:#7a5210}.cg-sync.busy{background:#eef5ff;border-color:#bcd3f5;color:#27456e}.cg-sync.ok{color:#3a6b3a}
.cg-toolbar{display:flex;align-items:center;gap:6px;padding:6px 14px;background:#faf9f5;border-bottom:1px solid var(--border);flex-wrap:wrap;flex-shrink:0}
.cg-touch .cg-toolbar{flex-wrap:nowrap;overflow-x:auto;padding:6px 8px}
.cg-tb{background:#fff;border:1px solid var(--border);border-radius:5px;padding:5px 10px;font-size:12px;cursor:pointer;color:var(--ink);font-family:inherit;white-space:nowrap;flex:none}
.cg-touch .cg-tb{padding:8px 12px;font-size:13px}
.cg-tb:hover:not(:disabled){border-color:var(--gold);background:#fffaf0}
.cg-tb:disabled{opacity:.38;cursor:default}
.cg-tb.primary{background:var(--gold);border-color:var(--gold);font-weight:700;color:var(--black)}
.cg-tb.on{background:var(--black);color:var(--gold);border-color:var(--black)}
.cg-sep{width:1px;height:20px;background:var(--border);margin:0 3px;flex:none}
.cg-seg{display:inline-flex;flex:none}.cg-seg .cg-tb{border-radius:0;margin-left:-1px}.cg-seg .cg-tb:first-child{border-radius:5px 0 0 5px;margin-left:0}.cg-seg .cg-tb:last-child{border-radius:0 5px 5px 0}
.cg-banner{display:none;padding:7px 14px;font-size:12.5px;background:#fff3e0;border-bottom:1px solid #f0c987;color:#7a5210;flex-shrink:0}
.cg-banner.show{display:block}.cg-banner.error{background:#fde8e8;border-color:#e3a3a3;color:#8a2c2c}.cg-banner.info{background:#eef5ff;border-color:#bcd3f5;color:#27456e}
.cg-body{flex:1;min-height:0;display:flex;flex-direction:column;position:relative}
.cg-gantt{flex:1;min-height:0;display:flex;flex-direction:column}
.cg-scroller{flex:1;min-height:0;overflow:auto;position:relative;background:#fff;-webkit-overflow-scrolling:touch}
.cg-chart{display:flex;width:max-content;min-width:100%;min-height:100%}
.cg-left{position:sticky;left:0;z-index:20;width:var(--leftW);flex:none;background:#fff;border-right:2px solid #d9d4c4}
.cg-cols{display:grid;grid-template-columns:var(--cols)}
.cg-lhead{position:sticky;top:0;z-index:5;height:var(--hdr);align-items:end;background:#f3f1ea;border-bottom:1px solid var(--border);font-size:10.5px;color:var(--muted);text-transform:uppercase;letter-spacing:.04em}
.cg-hcell{position:relative;padding:0 6px 8px;white-space:nowrap;overflow:hidden;user-select:none}
.cg-hcell.r{text-align:right}.cg-hcell:first-child{text-align:center;padding-left:0;padding-right:0}
.cg-colrs{position:absolute;right:0;top:0;bottom:0;width:7px;cursor:col-resize;touch-action:none}
.cg-colrs:hover{background:rgba(213,175,52,.4)}
.cg-touch .cg-colrs{width:14px}
.cg-lrow{height:var(--row);border-bottom:1px solid #f0ede4;align-items:center}
.cg-lrow:hover{background:#fbf9f2}.cg-lrow.sel{background:#fff6dc}
.cg-c{position:relative;padding:0 6px;overflow:hidden;white-space:nowrap;height:100%;display:flex;align-items:center;min-width:0}
.cg-c.n{color:var(--muted);font-size:11px;justify-content:center;padding:0;cursor:pointer;overflow:visible}
.cg-c.n:hover{color:var(--ink);background:#f0ece0}
.cg-rowrs{position:absolute;left:0;right:0;bottom:-3px;height:7px;cursor:row-resize;z-index:3;touch-action:none}
.cg-rowrs:hover{background:rgba(213,175,52,.45)}
.cg-c.r{justify-content:flex-end}.cg-c.mono{font-variant-numeric:tabular-nums}.cg-c.edit{cursor:text}.cg-c.ro{cursor:default;color:#55503f}
.cg-nm{overflow:hidden;text-overflow:ellipsis;min-width:0}
.cg-lrow.summary .cg-nm{font-weight:700}
.cg-tg{display:inline-block;width:16px;text-align:center;cursor:pointer;color:#6b6656;font-size:10px;user-select:none;flex:none}
.cg-touch .cg-tg{width:24px;font-size:13px}
.cg-sp{display:inline-block;width:16px;flex:none}.cg-touch .cg-sp{width:24px}
.cg-ce{width:100%;height:calc(var(--row) - 8px);max-height:28px;border:1px solid var(--gold);border-radius:3px;padding:0 4px;font-size:12.5px;font-family:inherit;outline:none;background:#fffdf4;min-width:0}
.cg-split{position:absolute;right:-6px;top:0;bottom:0;width:10px;cursor:col-resize;z-index:30;touch-action:none}
.cg-split:hover{background:rgba(213,175,52,.3)}.cg-touch .cg-split{width:18px;right:-10px}
.cg-right{position:relative;flex:none}
.cg-rhead{position:sticky;top:0;z-index:10;height:var(--hdr);background:#f3f1ea;border-bottom:1px solid var(--border);overflow:hidden}
.cg-hc{position:absolute;font-size:10.5px;color:#55503f;display:flex;flex-direction:column;align-items:center;justify-content:center;overflow:hidden}
.cg-hc.top{height:26px;top:0;align-items:flex-start;padding-left:6px;font-weight:700;letter-spacing:.03em;border-left:1px solid #d9d4c4;border-bottom:1px solid #e0dbcb;white-space:nowrap}
.cg-hc.bot{top:26px;height:32px;border-left:1px solid #e6e2d4}
.cg-hc.bot .dl{font-size:9px;color:var(--muted);line-height:11px}.cg-hc.bot .dn{font-size:11px;line-height:13px;font-weight:700}
.cg-hc.bot.we{background:#e9e6da}.cg-hc.bot.today{background:var(--gold);color:var(--black)}.cg-hc.bot.today .dl{color:var(--black)}
.cg-canvas{position:relative}
.cg-we{position:absolute;top:0;bottom:0;background-color:#f6f5f0;background-image:repeating-linear-gradient(135deg,rgba(0,0,0,.05) 0 2px,transparent 2px 6px);pointer-events:none}
.cg-mline{position:absolute;top:0;bottom:0;width:1px;background:#e0dbcb;pointer-events:none}
.cg-rowsel{position:absolute;left:0;right:0;background:rgba(255,226,140,.28);pointer-events:none}
.cg-today{position:absolute;top:0;bottom:0;width:2px;background:#d64545;opacity:.7;pointer-events:none;z-index:6}
.cg-bar{position:absolute;border-radius:3px;cursor:grab;user-select:none;-webkit-user-select:none;-webkit-touch-callout:none;touch-action:none}
.cg-fill{height:100%;border-radius:3px 0 0 3px;pointer-events:none}
.cg-h{position:absolute;top:0;bottom:0;width:8px;cursor:ew-resize;z-index:2}.cg-h.l{left:-2px}.cg-h.r{right:-2px}
.cg-touch .cg-h{width:16px}.cg-touch .cg-h.l{left:-6px}.cg-touch .cg-h.r{right:-6px}
.cg-bar.blocked{box-shadow:0 0 0 2px #c0392b}
.cg-bar.cg-sum{cursor:default;clip-path:polygon(0 0,100% 0,100% 100%,calc(100% - 6px) 55%,6px 55%,0 100%)}
.cg-bar.cg-sum .cg-fill{border-radius:0}
.cg-ms{position:absolute;cursor:grab;touch-action:none;-webkit-touch-callout:none;user-select:none}
.cg-msd{position:absolute;inset:2px;transform:rotate(45deg);border:2px solid #fff;box-shadow:0 0 0 1.5px #3d3a2e}
.cg-ms.blocked .cg-msd{box-shadow:0 0 0 2px #c0392b}
.cg-lh{position:absolute;top:50%;width:11px;height:11px;margin-top:-5.5px;border-radius:50%;background:#fff;border:2px solid #3d3a2e;display:none;cursor:crosshair;z-index:9;touch-action:none}
.cg-lh.l{left:-18px}.cg-lh.r{right:-18px}
.cg-bar:hover .cg-lh,.cg-bar.sel .cg-lh,.cg-ms:hover .cg-lh,.cg-ms.sel .cg-lh{display:block}
.cg-lh:hover{background:var(--gold)}
.cg-touch .cg-lh{width:22px;height:22px;margin-top:-11px}.cg-touch .cg-lh.l{left:-30px}.cg-touch .cg-lh.r{right:-30px}
.cg-bar.cg-target-start{box-shadow:-4px 0 0 var(--gold)}.cg-bar.cg-target-end{box-shadow:4px 0 0 var(--gold)}
.cg-ms.cg-target-start .cg-msd,.cg-ms.cg-target-end .cg-msd{box-shadow:0 0 0 3px var(--gold)}
.cg-lbl{position:absolute;white-space:nowrap;pointer-events:none;color:#2a2822}
.cg-lbl .pc{margin:0 6px;font-weight:700}.cg-lbl .as{color:#5f5a49}
.cg-dep{position:absolute;left:0;top:0;pointer-events:none;z-index:7}
.cg-lhit{fill:none;stroke:transparent;stroke-width:12;pointer-events:stroke;cursor:context-menu}
.cg-touch .cg-lhit{stroke-width:20}
.cg-link{fill:none;stroke:#6b6656;stroke-width:1.2;pointer-events:none}
.cg-link.hard{stroke:#1c1a16;stroke-width:1.9}
.cg-link.bad{stroke:#d97706;stroke-dasharray:5 3}
.cg-lhit:hover + .cg-link{stroke:var(--gold);stroke-width:2.4}
.cg-rubber{fill:none;stroke:var(--gold);stroke-width:2;stroke-dasharray:4 3;pointer-events:none}
.cg-tip{position:fixed;z-index:1000;background:#1c1a16;color:#fff;font-size:11.5px;padding:4px 8px;border-radius:4px;pointer-events:none;display:none;white-space:nowrap}
.cg-overlay{position:fixed;inset:0;background:rgba(0,0,0,.18);z-index:940;display:none}.cg-overlay.show{display:block}
.cg-panel{position:fixed;top:0;right:-440px;width:min(400px,100vw);height:100vh;background:#fff;border-left:1px solid var(--border);box-shadow:-4px 0 16px rgba(0,0,0,.1);transition:right .18s;padding:16px;overflow:auto;z-index:950;color:var(--ink);font-family:Arial,sans-serif;font-size:13px}
.cg-panel.open{right:0}
.cg-panel *{box-sizing:border-box}
.cg-panel h2{font-family:'Arial Narrow',Arial,sans-serif;text-transform:uppercase;font-size:17px;margin:0 0 12px}
.cg-f{margin-bottom:11px}.cg-f label{display:block;font-size:11.5px;color:var(--muted);margin-bottom:3px}
.cg-f input[type=text],.cg-f input[type=date],.cg-f input[type=number],.cg-f select,.cg-padd{width:100%;padding:7px 9px;border:1px solid var(--border);border-radius:5px;font-size:13px;font-family:inherit;background:#fff}
.cg-f.chk label{display:flex;align-items:center;gap:8px;color:var(--ink);font-size:13px}
.cg-prow{display:grid;grid-template-columns:1fr 58px 50px 46px 22px;gap:4px;align-items:center;margin-bottom:5px;font-size:12px}
.cg-prow select,.cg-prow input[type=number]{padding:4px;border:1px solid var(--border);border-radius:4px;font-size:12px;width:100%}
.cg-prow .pn{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.cg-prow button{border:none;background:transparent;color:#b23;font-size:16px;cursor:pointer}
.cg-pactions{display:flex;gap:8px;margin-top:14px}
.cg-danger{margin-left:auto;background:transparent;border:1px solid #b23;color:#b23;border-radius:5px;padding:6px 12px;cursor:pointer;font-size:12px;font-family:inherit}
.cg-menu{position:fixed;z-index:1100;display:none;background:#fff;border:1px solid #d9d4c4;border-radius:7px;box-shadow:0 8px 24px rgba(0,0,0,.2);padding:4px;min-width:210px;max-width:290px;max-height:80vh;overflow:auto;font-family:Arial,sans-serif;font-size:13px;color:var(--ink)}
.cg-mi{display:flex;align-items:center;gap:6px;padding:7px 10px;border-radius:4px;cursor:pointer;white-space:nowrap}
.cg-touch .cg-mi{padding:11px 12px;font-size:14px}
.cg-mi:hover{background:#fff3cf}.cg-mi.dis{opacity:.4;cursor:default}.cg-mi.dis:hover{background:transparent}.cg-mi.danger{color:#b23}
.cg-mchk{width:14px;flex:none;color:#8a6d00;font-weight:700}.cg-mhint{margin-left:auto;padding-left:14px;color:var(--muted);font-size:11.5px}
.cg-msep{height:1px;background:#eee9da;margin:4px 2px}
.cg-dlg{position:fixed;inset:0;background:rgba(0,0,0,.3);z-index:1200;display:none;align-items:center;justify-content:center;padding:16px}
.cg-dbox{background:#fff;border-radius:10px;padding:18px;width:min(380px,100%);box-shadow:0 12px 40px rgba(0,0,0,.3);font-family:Arial,sans-serif;font-size:13px;color:var(--ink)}
.cg-dtitle{font-weight:700;font-size:15px;margin-bottom:6px}.cg-dmsg{color:#55503f;margin-bottom:10px;line-height:1.5}
.cg-din{width:100%;padding:8px 10px;border:1px solid var(--border);border-radius:5px;font-size:14px;margin-bottom:12px}
.cg-dbtns{display:flex;gap:8px;justify-content:flex-end}
.cg-empty{padding:30px 14px;color:var(--muted);line-height:1.6}
.cg-help{flex:1;min-height:0;overflow:auto;padding:20px 24px 60px;background:#fff;line-height:1.55}
.cg-help .wrap{max-width:820px;margin:0 auto}
.cg-help h1{font-family:'Arial Narrow',Arial,sans-serif;text-transform:uppercase;font-size:22px;margin:0 0 4px}
.cg-help .lead{color:var(--muted);margin:0 0 18px}
.cg-help details{border:1px solid var(--border);border-radius:8px;margin-bottom:10px;background:#fcfbf7}
.cg-help summary{cursor:pointer;padding:11px 14px;font-weight:700;font-size:14px}
.cg-help .sec{padding:0 16px 12px}
.cg-help ul{margin:6px 0;padding-left:20px}.cg-help li{margin:4px 0}
.cg-help kbd{background:#efece2;border:1px solid #d9d4c4;border-radius:4px;padding:1px 6px;font-size:11.5px;font-family:inherit}
.cg-help .tip{background:#fff6dc;border-left:3px solid var(--gold);padding:8px 12px;margin:8px 0;border-radius:0 5px 5px 0}
.cg-help table{border-collapse:collapse;margin:6px 0;font-size:12.5px}.cg-help td,.cg-help th{border:1px solid var(--border);padding:5px 10px;text-align:left}
`;

const TEMPLATE = `
<div class="cg-tabs"><button class="cg-tab on" data-tab="gantt">Schedule</button><button class="cg-tab" data-tab="help">Help</button><span class="cg-save"></span><button class="cg-sync" data-act="sync" style="display:none"></button></div>
<div class="cg-toolbar">
  <button class="cg-tb primary" data-act="add">+ Task</button>
  <button class="cg-tb" data-act="ms">◆ Milestone</button>
  <span class="cg-sep"></span>
  <button class="cg-tb" data-act="indent" title="Make the selected task a sub-task of the task above it">Indent →</button>
  <button class="cg-tb" data-act="outdent">← Outdent</button>
  <button class="cg-tb" data-act="up" title="Move up">↑</button>
  <button class="cg-tb" data-act="down" title="Move down">↓</button>
  <button class="cg-tb" data-act="del">Delete</button>
  <span class="cg-sep"></span>
  <div class="cg-seg"><button class="cg-tb" data-zoom="32">Day</button><button class="cg-tb" data-zoom="14">Week</button><button class="cg-tb" data-zoom="4">Month</button></div>
  <button class="cg-tb" data-act="zoomout" title="Narrower days">−</button><button class="cg-tb" data-act="zoomin" title="Wider days">+</button>
  <button class="cg-tb" data-act="today">Today</button>
  <button class="cg-tb" data-act="collapse">Collapse all</button><button class="cg-tb" data-act="expand">Expand all</button>
  <span class="cg-sep"></span>
  <button class="cg-tb" data-act="locks" title="When on, LOCKED links keep dates in line. Soft links never move anything.">Locked links: on</button>
  <button class="cg-tb" data-act="view" title="Columns, row height, labels, connectors… (also: right-click anywhere)">⚙ View</button>
  <button class="cg-tb" data-act="full" title="Full screen">⤢</button>
</div>
<div class="cg-banner"></div>
<div class="cg-body">
  <div class="cg-gantt">
    <div class="cg-scroller"><div class="cg-chart">
      <div class="cg-left"><div class="cg-lhead cg-cols"></div><div class="cg-lrows"></div><div class="cg-split" title="Drag to resize the table"></div></div>
      <div class="cg-right"><div class="cg-rhead"></div><div class="cg-canvas"></div></div>
    </div></div>
  </div>
  <div class="cg-help" style="display:none"></div>
</div>
<div class="cg-tip"></div><div class="cg-overlay"></div><div class="cg-menu"></div>
<div class="cg-dlg"><div class="cg-dbox"><div class="cg-dtitle"></div><div class="cg-dmsg"></div><input class="cg-din" type="text"><div class="cg-dbtns"><button class="cg-tb primary" data-ok>OK</button><button class="cg-tb" data-cancel>Cancel</button></div></div></div>
<div class="cg-panel">
  <h2 class="cg-ptitle">Task details</h2>
  <div class="cg-f"><label>Task name</label><input type="text" data-pf="task"></div>
  <div class="cg-f"><label>Start</label><input type="date" data-pf="start"></div>
  <div class="cg-f"><label>Finish</label><input type="date" data-pf="end"></div>
  <div class="cg-f"><label>% complete</label><input type="number" min="0" max="100" data-pf="percent"></div>
  <div class="cg-f"><label>Status</label><select data-pf="status"><option>Not Started</option><option>In Progress</option><option>Complete</option><option>Blocked</option></select></div>
  <div class="cg-f"><label>Assigned to</label><input type="text" data-pf="assignedTo"></div>
  <div class="cg-f" data-pw="links"><label>Predecessors — what this task waits on</label><div class="cg-plinks"></div><select class="cg-padd"></select></div>
  <div class="cg-f" data-pw="parent"><label>Parent group</label><select data-pf="parent"></select></div>
  <div class="cg-f chk" data-pw="milestone"><label><input type="checkbox" data-pf="milestone"> Milestone (single-day diamond)</label></div>
  <div class="cg-f"><label>Linked folder (Drive URL)</label><input type="text" data-pf="folder"></div>
  <div class="cg-pactions"><button class="cg-tb primary" data-p="save">Save</button><button class="cg-tb" data-p="cancel">Cancel</button><button class="cg-danger" data-p="delete">Delete</button></div>
</div>`;

const HELP_HTML = `<div class="wrap">
<h1>Celestial Gantt — Help</h1>
<p class="lead">The same scheduler on your PC and your phone. Everything saves to Notion, so both always show the same plan.</p>

<details open><summary>1 · Quick start</summary><div class="sec"><ul>
<li><b>+ Task</b> adds a row under the selected one and lets you type its name straight away. <b>◆ Milestone</b> adds a single-day diamond.</li>
<li>Click a row to select it. <b>Click a cell of the selected row</b> to edit it (name, start, finish, duration, %, predecessors).</li>
<li>Click the <b>row number</b> — or double-tap/double-click a bar — for the full details panel.</li>
<li><b>Drag a bar</b> to move it, drag its <b>ends</b> to change the length. A tooltip shows the dates while you drag.</li>
<li>Turn on <b>Day / Week / Month</b> zoom, or use <b>− +</b> (desktop: <kbd>Ctrl</kbd>+mouse wheel) to set any width.</li>
</ul><div class="tip">Not sure? <b>Right-click</b> (phone: <b>press and hold</b>) on a task, an arrow, a column heading or empty chart. Most settings live in those menus.</div></div></details>

<details><summary>2 · Groups (summary tasks)</summary><div class="sec"><ul>
<li>Select a task and press <b>Indent →</b> to make it a sub-task of the task above. The task above becomes a <b>group</b> with a summary bar that spans its sub-tasks and shows their average progress.</li>
<li><b>← Outdent</b> moves it back up a level. <b>↑ ↓</b> reorder. Click the <b>▾</b> arrow to collapse a group.</li>
<li>A group's dates and % are calculated from its sub-tasks — you can't type over them.</li>
<li>Task names must be <b>unique</b> (groups link to their sub-tasks by name).</li></ul></div></details>

<details><summary>3 · Links between tasks (dependencies)</summary><div class="sec">
<p><b>Draw a link:</b> hover a bar (or tap it on the phone) and small circles appear at both ends. <b>Drag from a circle onto another bar</b> — the task you start from is the <i>predecessor</i>, the one you drop on is the <i>successor</i>. Drop on the <b>left half</b> of the target to link to its start, the <b>right half</b> for its finish.</p>
<table><tr><th>Drag from</th><th>Drop on</th><th>Link</th></tr>
<tr><td>finish (right circle)</td><td>left half</td><td><b>FS</b> Finish → Start (the usual one)</td></tr>
<tr><td>start (left circle)</td><td>left half</td><td><b>SS</b> Start → Start</td></tr>
<tr><td>finish (right circle)</td><td>right half</td><td><b>FF</b> Finish → Finish</td></tr>
<tr><td>start (left circle)</td><td>right half</td><td><b>SF</b> Start → Finish</td></tr></table>
<p><b>Links are soft by default.</b> The arrow is drawn but nothing is forced: you can drag tasks wherever you like. If a task is placed so that it breaks its link, the arrow turns <b>dashed amber</b> as a warning.</p>
<p><b>Locked links</b> are firm. Right-click an arrow and tick <b>Locked</b>: the successor is pushed later whenever the predecessor moves, and it snaps back if you drag it too early. (Locks only ever push tasks <i>later</i>. The toolbar's <b>Locked links</b> button switches all locks on/off at once.)</p>
<p><b>Right-click an arrow</b> to lock/unlock it, change its type, set a <b>lag</b> (days after the predecessor; negative = overlap), or delete it. Hover an arrow to highlight it.</p>
<p><b>Pred column:</b> type row numbers like <kbd>3</kbd>, <kbd>3, 5</kbd>, <kbd>4SS+2</kbd> (row 4, start-to-start, 2 days lag) or a task name. The details panel has a full list with the same options.</p></div></details>

<details><summary>4 · Right-click / press-and-hold menus</summary><div class="sec"><ul>
<li><b>On a task</b> (row or bar): edit details, add task / sub-task / milestone, toggle <i>Milestone</i>, <i>Complete</i> and <i>Blocked</i>, indent/outdent, move, clear its links, delete.</li>
<li><b>On an arrow:</b> locked, link type, lag, delete.</li>
<li><b>On a column heading:</b> show/hide WBS, Start, Finish, Duration, %, Pred, Resource, Status.</li>
<li><b>On empty chart</b> (or the <b>⚙ View</b> button): labels, connectors, weekend shading, today line, row height, zoom, locked links, full screen, reset sizes.</li></ul></div></details>

<details><summary>5 · Sizes: columns, rows, zoom</summary><div class="sec"><ul>
<li><b>Column width:</b> drag the right edge of a column heading. Dragging the edge of <i>Task name</i> (or the thick divider) resizes the whole table.</li>
<li><b>Row height:</b> drag the bottom edge of any row number up or down — all rows follow. (Or pick Compact / Normal / Comfortable / Large in the View menu.)</li>
<li><b>Day width:</b> <b>− +</b> buttons, <kbd>Ctrl</kbd>+wheel, or the Day / Week / Month presets. The heading switches style automatically.</li>
<li>Your sizes and view choices are remembered on this device. <b>Reset sizes</b> in the View menu puts everything back.</li></ul></div></details>

<details><summary>6 · Saving & syncing</summary><div class="sec"><ul>
<li>Every change saves to Notion immediately (see “Saved” at the top right). The PC and phone read the same data — press <b>↻</b> / reopen to refresh the other device.</li>
<li>If a save fails you'll see a red message and the chart reloads from Notion, so you never keep a change that didn't save.</li></ul></div></details>

<details><summary>7 · Troubleshooting</summary><div class="sec"><ul>
<li><b>Blue message about missing fields</b> — the Schedule Tasks database in Notion needs: PARENT TASK (Text), MILESTONE (Checkbox), SORT ORDER (Number), PREDECESSORS (Text). Features that need a missing one are switched off until you add it.</li>
<li><b>“Another task already has that name”</b> — rename it; names must be unique.</li>
<li><b>An arrow won't draw</b> — both tasks need dates and must be visible (expand collapsed groups). Links that would form a loop are refused.</li>
<li><b>Nothing happens when I drag a task earlier</b> — it has a <i>locked</i> link. Right-click the arrow and untick Locked (or switch “Locked links” off).</li></ul></div></details>
</div>`;

let cssDone = false;
function injectCss() {
  if (cssDone || typeof document === "undefined") return;
  const s = document.createElement("style"); s.setAttribute("data-cg", ""); s.textContent = CSS; document.head.appendChild(s); cssDone = true;
}

function create(root, cfg) {
  cfg = cfg || {};
  injectCss();
  root.classList.add("cg");
  const touch = cfg.touch !== undefined ? !!cfg.touch : (("ontouchstart" in global) || !!(global.matchMedia && global.matchMedia("(pointer:coarse)").matches));
  if (touch) root.classList.add("cg-touch");
  root.innerHTML = TEMPLATE;
  const q = (s) => root.querySelector(s), qa = (s) => root.querySelectorAll(s);
  const A = cfg.adapter, prefix = cfg.prefix || "gantt-";
  const LS = (k, d) => { try { const v = localStorage.getItem(prefix + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } };
  const LSset = (k, v) => { try { localStorage.setItem(prefix + k, JSON.stringify(v)); } catch (e) {} };
  const narrow = touch && (global.innerWidth || 1000) < 800;
  const uid = Math.random().toString(36).slice(2, 7);

  const state = {
    projectId: cfg.projectId || null, tasks: [], caps: { parent: false, milestone: false, sortOrder: false, predecessors: false },
    selectedId: null, collapsed: new Set(),
    px: LS("px", 32), leftW: LS("leftw", narrow ? 190 : 620), rowH: LS("rowh", touch ? 40 : 34),
    colsVisible: LS("cols", narrow ? ["pct"] : ["wbs", "start", "end", "dur", "pct", "pred"]), colW: LS("colw", {}),
    view: Object.assign({ labels: true, connectors: true, weekends: true, today: true }, LS("view", {})),
    auto: LS("auto", true), tab: "gantt", editing: null, pendingEdit: null, panelId: null, panelLinks: [], model: null, saving: 0,
  };
  let ROW = state.rowH, destroyed = false, lastRenderAt = 0;
  const el = {
    scroller: q(".cg-scroller"), lhead: q(".cg-lhead"), lrows: q(".cg-lrows"), rhead: q(".cg-rhead"), right: q(".cg-right"), canvas: q(".cg-canvas"),
    banner: q(".cg-banner"), save: q(".cg-save"), tip: q(".cg-tip"), panel: q(".cg-panel"), overlay: q(".cg-overlay"), menu: q(".cg-menu"),
    dlg: q(".cg-dlg"), help: q(".cg-help"), gantt: q(".cg-gantt"), toolbar: q(".cg-toolbar"),
  };
  el.help.innerHTML = HELP_HTML;

  const visibleCols = () => COLS.filter((c) => c.fixed || state.colsVisible.indexOf(c.k) >= 0);
  const colWidth = (c) => state.colW[c.k] || c.w;
  function applyVars() {
    root.style.setProperty("--leftW", state.leftW + "px"); root.style.setProperty("--row", ROW + "px");
    root.style.setProperty("--cols", visibleCols().map((c) => (c.flex ? "minmax(60px,1fr)" : colWidth(c) + "px")).join(" "));
  }
  const byId = (id) => state.tasks.find((t) => t.id === id);
  const sel = () => byId(state.selectedId);
  let toastTimer = null;
  function showBanner(text, kind) { clearTimeout(toastTimer); el.banner.textContent = text; el.banner.className = "cg-banner show" + (kind === "error" || kind === true ? " error" : kind === "info" ? " info" : ""); }
  function hideBanner() { el.banner.className = "cg-banner"; }
  function toast(text, ms) { showBanner(text, "info"); toastTimer = setTimeout(hideBanner, ms || 4500); }
  function setSave(t) { el.save.textContent = t; }
  const geom = () => { const bh = Math.max(10, Math.round(ROW * 0.53)); return { bh, top: Math.round((ROW - bh) / 2), sh: Math.max(7, Math.round(bh * 0.67)), ms: Math.round(bh * 0.95), fs: Math.max(10, Math.min(12.5, Math.round(bh * 0.66))) }; };

  /* ---------------- model ---------------- */
  function liveStart(t, depth) { depth = depth || 0; if (depth > 40) return null; if (!t._summary) return t.start; let m = null; t._kids.forEach((k) => { const s = liveStart(k, depth + 1); if (s && (!m || s < m)) m = s; }); return m; }
  function liveEnd(t, depth) { depth = depth || 0; if (depth > 40) return null; if (!t._summary) return t.end || t.start; let m = null; t._kids.forEach((k) => { const e = liveEnd(k, depth + 1); if (e && (!m || e > m)) m = e; }); return m; }
  function descendantIds(t, out, depth) { out = out || new Set(); depth = depth || 0; if (depth > 40) return out; (t._kids || []).forEach((k) => { out.add(k.id); descendantIds(k, out, depth + 1); }); return out; }
  function uniqueName(base) { const names = new Set(state.tasks.map((t) => t.task)); if (!names.has(base)) return base; let i = 2; while (names.has(base + " " + i)) i++; return base + " " + i; }

  function rollup(t, seen) {
    if (seen.has(t.id)) return; seen.add(t.id);
    if (!t._summary) { t._s = t.start; t._e = t.end || t.start; t._pct = t.percent || 0; t._dur = t.start ? diffDays(t._e, t.start) + 1 : 0; return; }
    let s = null, e = null, w = 0, ws = 0;
    t._kids.forEach((k) => { rollup(k, seen); if (k._s && (!s || k._s < s)) s = k._s; if (k._e && (!e || k._e > e)) e = k._e; const d = Math.max(1, k._dur || 1); ws += (k._pct || 0) * d; w += d; });
    t._s = s; t._e = e; t._pct = w ? Math.round(ws / w) : 0; t._dur = s && e ? diffDays(e, s) + 1 : 0;
  }

  function computeModel() {
    const tasks = state.tasks, caps = state.caps;
    const byName = new Map(), idMap = new Map();
    tasks.forEach((t) => { idMap.set(t.id, t); if (!byName.has(t.task)) byName.set(t.task, t); });
    const kids = new Map(), roots = [];
    tasks.forEach((t) => {
      const p = caps.parent && t.parent && t.parent !== t.task ? byName.get(t.parent) : null;
      t._parent = p || null;
      if (p) { if (!kids.has(p.id)) kids.set(p.id, []); kids.get(p.id).push(t); } else roots.push(t);
    });
    const cmp = (a, b) => ((a.sortOrder == null ? 1e9 : a.sortOrder) - (b.sortOrder == null ? 1e9 : b.sortOrder)) || String(a.createdTime).localeCompare(String(b.createdTime));
    const flat = [], seen = new Set();
    function walk(t, level, wbs, ci) {
      if (seen.has(t.id)) return; seen.add(t.id);
      t._level = level; t._wbs = wbs; t._ci = ci; t._idx = flat.length;
      const ks = (kids.get(t.id) || []).slice().sort(cmp); t._kids = ks; t._summary = ks.length > 0; flat.push(t);
      ks.forEach((k, i) => walk(k, level + 1, wbs + "." + (i + 1), ci));
    }
    roots.sort(cmp); roots.forEach((t, i) => walk(t, 0, String(i + 1), i));
    tasks.forEach((t) => { if (!seen.has(t.id)) { t._parent = null; walk(t, 0, String(flat.length + 1), flat.length); } });  // safety net: circular parents
    const links = [];
    tasks.forEach((t) => {
      let raw = t.links && t.links.length ? t.links : [];
      if (!raw.length && t.dependsOn) { const lp = byName.get(t.dependsOn); if (lp) raw = [{ p: lp.id, t: "FS", l: 0, h: 0 }]; }   // older single-name link
      t._links = [];
      raw.forEach((L) => { const p = idMap.get(L.p); if (!p || p === t) return; const o = { pTask: p, tTask: t, p: p.id, t: L.t, l: L.l || 0, h: L.h ? 1 : 0 }; t._links.push(o); links.push(o); });
    });
    const rs = new Set(); flat.forEach((t) => rollup(t, rs));
    const visible = []; let hide = null;
    flat.forEach((t) => { if (hide !== null && t._level > hide) return; hide = null; visible.push(t); if (t._summary && state.collapsed.has(t.id)) hide = t._level; });
    const visIndex = new Map(); visible.forEach((t, i) => visIndex.set(t.id, i));
    const dates = flat.flatMap((t) => [t._s, t._e]).filter(Boolean).sort();
    let min = dates[0] || todayStr(), max = dates[dates.length - 1] || addDays(todayStr(), 28);
    min = addDays(min, -5); max = addDays(max, 14); min = addDays(min, -parseDate(min).getUTCDay());
    if (diffDays(max, min) < 56) max = addDays(min, 56);
    const px = state.px, need = Math.ceil(Math.max(0, el.scroller.clientWidth - state.leftW) / px) + 7;
    if (diffDays(max, min) + 1 < need) max = addDays(min, need);
    max = addDays(max, 6 - parseDate(max).getUTCDay());
    return (state.model = { flat, visible, visIndex, byName, idMap, roots: flat.filter((t) => t._level === 0), links, range: { min, days: diffDays(max, min) + 1 }, px, mode: px >= 18 ? "day" : px >= 7 ? "week" : "month" });
  }

  // How many days too early is a task, given one link? (> 0 means the link is broken)
  function linkNeed(L, s, e) {
    const ps = liveStart(L.pTask), pe = liveEnd(L.pTask);
    if (!ps || !pe || !s) return 0; e = e || s;
    if (L.t === "SS") return diffDays(addDays(ps, L.l), s);
    if (L.t === "FF") return diffDays(addDays(pe, L.l), e);
    if (L.t === "SF") return diffDays(addDays(ps, L.l), e);
    return diffDays(addDays(pe, 1 + L.l), s);
  }
  const linkText = (L, M) => (L.pTask._idx + 1) + (L.t !== "FS" ? L.t : "") + (L.l ? (L.l > 0 ? "+" : "") + L.l : "");
  const predText = (t, M) => (t._links || []).map((L) => linkText(L, M)).join(", ");

  /* ---------------- rendering ---------------- */
  function render() {
    if (destroyed || state.editing || state.tab !== "gantt") return;
    const M = computeModel();
    renderHead(); renderLeft(M); renderRight(M); updateToolbar(); lastRenderAt = Date.now();
    if (state.pendingEdit) {
      const pe = state.pendingEdit; state.pendingEdit = null; startEdit(pe.id, pe.field);
      const row = q('.cg-lrow[data-id="' + pe.id + '"]'); if (row && row.scrollIntoView) row.scrollIntoView({ block: "nearest" });
    }
  }

  function renderHead() {
    applyVars();
    el.lhead.innerHTML = visibleCols().map((c) => '<div class="cg-hcell' + (c.right ? " r" : "") + '" data-col="' + c.k + '">' + esc(c.t) + '<span class="cg-colrs" data-colrs="' + c.k + '"></span></div>').join("");
  }

  function cell(t, c, M) {
    const ro = t._summary ? " ro" : " edit";
    switch (c.k) {
      case "n": return '<div class="cg-c n" title="Task details">' + (t._idx + 1) + '<span class="cg-rowrs" data-rowrs="1"></span></div>';
      case "name": return '<div class="cg-c edit" data-f="name" style="padding-left:' + (6 + t._level * (touch ? 14 : 16)) + 'px">' + (t._summary ? '<span class="cg-tg" data-tg="1">' + (state.collapsed.has(t.id) ? "▸" : "▾") + "</span>" : '<span class="cg-sp"></span>') + '<span class="cg-nm">' + esc(t.task) + "</span></div>";
      case "wbs": return '<div class="cg-c mono" style="color:#8a8578">' + t._wbs + "</div>";
      case "start": return '<div class="cg-c mono' + ro + '" data-f="start">' + showDate(t._s) + "</div>";
      case "end": return '<div class="cg-c mono' + ro + '" data-f="end">' + showDate(t._e) + "</div>";
      case "dur": return '<div class="cg-c r mono' + ro + '" data-f="dur">' + (t.milestone && !t._summary ? "0d" : t._dur ? t._dur + "d" : "") + "</div>";
      case "pct": return '<div class="cg-c r mono' + ro + '" data-f="pct">' + (t._pct || 0) + "%</div>";
      case "pred": return '<div class="cg-c r mono' + ro + '" data-f="pred">' + esc(predText(t, M)) + "</div>";
      case "res": return '<div class="cg-c' + ro + '" data-f="res">' + (t._summary ? "" : esc(t.assignedTo)) + "</div>";
      case "status": return '<div class="cg-c' + ro + '" data-f="status">' + (t._summary ? "" : esc(t.status)) + "</div>";
    }
    return "";
  }

  function renderLeft(M) {
    const H = Math.max(M.visible.length * ROW, el.scroller.clientHeight - HDR - 2);
    el.lrows.style.minHeight = H + "px";
    if (!state.projectId) { el.lrows.innerHTML = '<div class="cg-empty">No project selected.</div>'; return; }
    if (M.flat.length === 0) { el.lrows.innerHTML = '<div class="cg-empty">No tasks yet for this project.<br>Tap <b>+ Task</b> to add the first one.</div>'; return; }
    el.lrows.innerHTML = M.visible.map((t) => '<div class="cg-lrow cg-cols' + (t.id === state.selectedId ? " sel" : "") + (t._summary ? " summary" : "") + '" data-id="' + t.id + '">' + visibleCols().map((c) => cell(t, c, M)).join("") + "</div>").join("");
  }

  function monthSegments(M) {
    const segs = []; let cur = null;
    for (let d = 0; d < M.range.days; d++) {
      const dt = parseDate(addDays(M.range.min, d)), key = dt.getUTCFullYear() * 12 + dt.getUTCMonth();
      if (!cur || cur.key !== key) { cur = { key, start: d, len: 0, y: dt.getUTCFullYear(), m: dt.getUTCMonth() }; segs.push(cur); }
      cur.len++;
    }
    return segs;
  }

  function headerHtml(M) {
    const { range, px, mode } = M, today = todayStr(); let h = "";
    if (mode === "day") {
      for (let d = 0; d < range.days; d += 7) { const dt = parseDate(addDays(range.min, d)); h += '<div class="cg-hc top" style="left:' + d * px + "px;width:" + 7 * px + 'px">' + MON[dt.getUTCMonth()] + " " + dt.getUTCDate() + ", " + dt.getUTCFullYear() + "</div>"; }
      for (let d = 0; d < range.days; d++) {
        const ds = addDays(range.min, d), dt = parseDate(ds), dow = dt.getUTCDay();
        h += '<div class="cg-hc bot' + (dow === 0 || dow === 6 ? " we" : "") + (ds === today ? " today" : "") + '" style="left:' + d * px + "px;width:" + px + 'px"><span class="dl">' + "SMTWTFS"[dow] + '</span><span class="dn">' + dt.getUTCDate() + "</span></div>";
      }
    } else if (mode === "week") {
      monthSegments(M).forEach((s) => { h += '<div class="cg-hc top" style="left:' + s.start * px + "px;width:" + s.len * px + 'px">' + MON[s.m] + " " + s.y + "</div>"; });
      for (let d = 0; d < range.days; d += 7) { const dt = parseDate(addDays(range.min, d)); h += '<div class="cg-hc bot" style="left:' + d * px + "px;width:" + 7 * px + 'px"><span class="dn">' + dt.getUTCDate() + "</span></div>"; }
    } else {
      const segs = monthSegments(M); let y = null;
      segs.forEach((s) => { if (s.y !== y) { y = s.y; const len = segs.filter((z) => z.y === y).reduce((a, z) => a + z.len, 0); h += '<div class="cg-hc top" style="left:' + s.start * px + "px;width:" + len * px + 'px">' + y + "</div>"; } });
      segs.forEach((s) => { h += '<div class="cg-hc bot" style="left:' + s.start * px + "px;width:" + s.len * px + 'px"><span class="dn">' + MON[s.m] + "</span></div>"; });
    }
    return h;
  }

  // elbow connector between two bar edges. ds: +1 leaves rightwards (from a finish), -1 leftwards (from a start). dt: +1 enters a start (moving right), -1 enters a finish (moving left)
  function route(x1, y1, x2, y2, ds, dt) {
    const g = 10, xv = x1 + ds * g, simple = dt > 0 ? x2 - xv >= g : xv - x2 >= g;
    if (simple) return "M" + x1 + "," + y1 + " H" + xv + " V" + y2 + " H" + x2;
    const ym = y2 > y1 ? y1 + ROW / 2 : y1 - ROW / 2, ex = x2 - dt * g;
    return "M" + x1 + "," + y1 + " H" + xv + " V" + ym + " H" + ex + " V" + y2 + " H" + x2;
  }

  function renderRight(M) {
    const { range, px, visible } = M, W = range.days * px, g = geom();
    const H = Math.max(visible.length * ROW, el.scroller.clientHeight - HDR - 2);
    el.right.style.width = W + "px"; el.rhead.style.width = W + "px"; el.rhead.innerHTML = headerHtml(M);
    const cv = el.canvas; cv.style.width = W + "px"; cv.style.height = H + "px";
    const layers = ["linear-gradient(to bottom,transparent " + (ROW - 1) + "px,#f0ede4 " + (ROW - 1) + "px)"], sizes = ["100% " + ROW + "px"];
    if (M.mode === "day") { layers.push("linear-gradient(to right,transparent " + (px - 1) + "px,#f1efe9 " + (px - 1) + "px)"); sizes.push(px + "px 100%"); }
    if (M.mode !== "month") { layers.push("linear-gradient(to right,#d9d4c4 1px,transparent 1px)"); sizes.push(7 * px + "px 100%"); }
    cv.style.backgroundImage = layers.join(","); cv.style.backgroundSize = sizes.join(",");

    let under = "";
    if (M.mode !== "month") {
      if (state.view.weekends) for (let d = 0; d < range.days; d++) {
        const dow = parseDate(addDays(range.min, d)).getUTCDay();
        if (dow === 6) under += '<div class="cg-we" style="left:' + d * px + "px;width:" + Math.min(2, range.days - d) * px + 'px"></div>';
        else if (dow === 0 && d === 0) under += '<div class="cg-we" style="left:0;width:' + px + 'px"></div>';
      }
    } else monthSegments(M).forEach((s) => { under += '<div class="cg-mline" style="left:' + s.start * px + 'px"></div>'; });
    const si = M.visIndex.get(state.selectedId);
    under += '<div class="cg-rowsel" style="top:' + (si !== undefined ? si * ROW : 0) + "px;height:" + ROW + "px;display:" + (si !== undefined ? "block" : "none") + '"></div>';
    const todayOff = diffDays(todayStr(), range.min);
    if (state.view.today && todayOff >= 0 && todayOff < range.days) under += '<div class="cg-today" style="left:' + (todayOff * px + px / 2 - 1) + 'px"></div>';

    let bars = "", labels = ""; const geo = new Map();
    visible.forEach((t, i) => {
      if (!t._s || !t._e) return;
      const col = PALETTE[t._ci % PALETTE.length], y = i * ROW, x0 = diffDays(t._s, range.min) * px, pct = Math.max(0, Math.min(100, t._pct || 0));
      const asg = t._summary || !t.assignedTo ? "" : esc(t.assignedTo), blocked = t.status === "Blocked" ? " blocked" : "", selC = t.id === state.selectedId ? " sel" : "";
      const lblStyle = "top:" + (y + g.top) + "px;height:" + g.bh + "px;line-height:" + g.bh + "px;font-size:" + g.fs + "px;";
      if (t.milestone && !t._summary) {
        const cx = x0 + px / 2, half = g.ms / 2; geo.set(t.id, { xs: cx - half, xe: cx + half, y: y + ROW / 2 });
        bars += '<div class="cg-ms' + blocked + selC + '" data-bar="' + t.id + '" style="left:' + (cx - half) + "px;top:" + (y + (ROW - g.ms) / 2) + "px;width:" + g.ms + "px;height:" + g.ms + 'px"><div class="cg-msd" style="background:' + col.dark + '"></div><div class="cg-lh l" data-lh="start"></div><div class="cg-lh r" data-lh="end"></div></div>';
        if (state.view.labels) labels += '<div class="cg-lbl" data-for="' + t.id + '" style="left:' + (cx + half + 8) + "px;" + lblStyle + '"><b>' + esc(t.task) + '</b><span class="pc"></span><span class="as">' + showDate(t._s) + "</span></div>";
        return;
      }
      const w = Math.max(px * 0.6, (diffDays(t._e, t._s) + 1) * px); geo.set(t.id, { xs: x0, xe: x0 + w, y: y + ROW / 2 });
      if (t._summary) bars += '<div class="cg-bar cg-sum' + selC + '" data-bar="' + t.id + '" style="left:' + x0 + "px;top:" + (y + Math.round((ROW - g.sh) / 2)) + "px;width:" + w + "px;height:" + g.sh + "px;background:" + col.light + '"><div class="cg-fill" style="width:' + pct + "%;background:" + col.dark + '"></div></div>';
      else bars += '<div class="cg-bar' + blocked + selC + '" data-bar="' + t.id + '" style="left:' + x0 + "px;top:" + (y + g.top) + "px;width:" + w + "px;height:" + g.bh + "px;background:" + col.light + '"><div class="cg-fill" style="width:' + pct + "%;background:" + col.dark + '"></div><div class="cg-h l"></div><div class="cg-h r"></div><div class="cg-lh l" data-lh="start"></div><div class="cg-lh r" data-lh="end"></div></div>';
      if (state.view.labels) labels += '<div class="cg-lbl" data-for="' + t.id + '" style="left:' + (x0 + w + 6) + "px;" + lblStyle + '"><b>' + esc(t.task) + '</b><span class="pc">' + pct + '%</span><span class="as">' + asg + "</span></div>";
    });
    let deps = "";
    if (state.view.connectors) M.links.forEach((L) => {
      const a = geo.get(L.p), b = geo.get(L.tTask.id); if (!a || !b) return;
      const fromEnd = L.t === "FS" || L.t === "FF", toStart = L.t === "FS" || L.t === "SS";
      const d = route(fromEnd ? a.xe : a.xs, a.y, toStart ? b.xs : b.xe, b.y, fromEnd ? 1 : -1, toStart ? 1 : -1);
      const bad = !L.h && linkNeed(L, L.tTask._s, L.tTask._e) > 0, cls = "cg-link" + (L.h ? " hard" : "") + (bad ? " bad" : "");
      deps += '<path class="cg-lhit" data-from="' + L.p + '" data-to="' + L.tTask.id + '" d="' + d + '"/><path class="' + cls + '" d="' + d + '" marker-end="url(#cgm-' + (bad ? "b" : L.h ? "h" : "n") + "-" + uid + ')"><title>' + esc(L.pTask.task + " → " + L.tTask.task + " (" + TYPE_NAMES[L.t] + (L.l ? ", lag " + L.l + "d" : "") + (L.h ? ", locked" : ", soft") + (bad ? " — dates break this link" : "") + ")") + "</title></path>";
    });
    const mk = (k, c) => '<marker id="cgm-' + k + "-" + uid + '" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 z" fill="' + c + '"/></marker>';
    cv.innerHTML = under + bars + labels + '<svg class="cg-dep" width="' + W + '" height="' + H + '"><defs>' + mk("n", "#6b6656") + mk("h", "#1c1a16") + mk("b", "#d97706") + "</defs>" + deps + "</svg>";
  }

  function updateRowSel() {
    const M = state.model, band = q(".cg-rowsel"); if (!M || !band) return;
    const i = M.visIndex.get(state.selectedId);
    if (i === undefined) band.style.display = "none"; else { band.style.display = "block"; band.style.top = i * ROW + "px"; }
  }
  function select(id) {
    state.selectedId = id;
    qa(".cg-lrow").forEach((r) => r.classList.toggle("sel", r.dataset.id === id));
    qa("[data-bar]").forEach((b) => b.classList.toggle("sel", b.dataset.bar === id));
    updateRowSel(); updateToolbar();
  }

  function updateToolbar() {
    const M = state.model, t = sel(), c = state.caps;
    const sibs = t && M ? (t._parent ? t._parent._kids : M.roots) : [], idx = t ? sibs.indexOf(t) : -1;
    const set = (a, dis) => { const b = q('[data-act="' + a + '"]'); if (b) b.disabled = !!dis; };
    set("add", !state.projectId); set("ms", !state.projectId || !c.milestone);
    set("indent", !(t && c.parent && idx > 0)); set("outdent", !(t && c.parent && t._parent));
    set("up", !(t && c.sortOrder && idx > 0)); set("down", !(t && c.sortOrder && idx >= 0 && idx < sibs.length - 1)); set("del", !t);
    qa("[data-zoom]").forEach((b) => b.classList.toggle("on", +b.dataset.zoom === Math.round(state.px)));
    const lk = q('[data-act="locks"]'); lk.classList.toggle("on", state.auto); lk.textContent = "Locked links: " + (state.auto ? "on" : "off");
    const ms = q('[data-act="ms"]'); ms.title = c.milestone ? "Add a single-day milestone" : "Needs the MILESTONE checkbox field on Schedule Tasks//DB";
  }

  /* ---------------- saving, links, scheduling ---------------- */
  const stripLink = (L) => ({ p: L.p, t: L.t, l: L.l || 0, h: L.h ? 1 : 0 });
  function linkUpdate(t, newLinks) {                      // fields to persist for a task's links (+ the older single-name mirror)
    const first = newLinks[0] && byId(newLinks[0].p);
    return { links: newLinks.map(stripLink), dependsOn: first ? first.task : "" };
  }
  function wouldCycle(fromId, toId) {                     // would a link fromId -> toId create a loop?
    if (fromId === toId) return true;
    const succ = new Map(); state.model.links.forEach((L) => { if (!succ.has(L.p)) succ.set(L.p, []); succ.get(L.p).push(L.tTask.id); });
    const stack = [toId], seen = new Set();
    while (stack.length) { const x = stack.pop(); if (x === fromId) return true; if (seen.has(x)) continue; seen.add(x); (succ.get(x) || []).forEach((y) => stack.push(y)); }
    return false;
  }
  // LOCKED links only: push a task later until its locked links hold, then push whatever is locked to it. Never pulls anything earlier.
  function computeCascade(seeds) {
    const out = new Map(), queue = seeds.slice(), M = state.model; let guard = 0;
    const hardSucc = new Map(); M.links.forEach((L) => { if (L.h) { if (!hardSucc.has(L.p)) hardSucc.set(L.p, []); hardSucc.get(L.p).push(L.tTask.id); } });
    while (queue.length && guard++ < 800) {
      const id = queue.shift(), t = byId(id); if (!t || t._summary || !t.start) continue;
      let shift = 0; (t._links || []).forEach((L) => { if (L.h) { const n = linkNeed(L, t.start, t.end); if (n > shift) shift = n; } });
      let changed = false;
      if (shift > 0) { const dur = diffDays(t.end || t.start, t.start); t.start = addDays(t.start, shift); t.end = addDays(t.start, dur); out.set(id, { start: t.start, end: t.end }); changed = true; }
      if (changed || seeds.indexOf(id) >= 0) { (hardSucc.get(id) || []).forEach((s) => queue.push(s)); for (let a = t._parent; a; a = a._parent) (hardSucc.get(a.id) || []).forEach((s) => queue.push(s)); }
    }
    return out;
  }

  async function commitUpdates(map, opts) {
    const cascade = !opts || opts.cascade !== false;
    map.forEach((u, id) => { const t = byId(id); if (t) Object.assign(t, u); });
    computeModel();
    if (cascade && state.auto) {
      const seeds = []; map.forEach((u, id) => { if ("start" in u || "end" in u || "links" in u) seeds.push(id); });
      const out = computeCascade(seeds);
      out.forEach((u, id) => map.set(id, Object.assign(map.get(id) || {}, u)));
      const moved = [...out.keys()].map((id) => byId(id) && byId(id).task).filter(Boolean);
      if (moved.length) toast("Locked link kept dates in line: " + moved.slice(0, 3).join(", ") + (moved.length > 3 ? " +" + (moved.length - 3) + " more" : "") + ".");
    }
    render();
    state.saving++; setSave("Saving…");
    try {
      let queued = false;
      for (const [id, u] of map) { const r = await A.patch(id, u, state.caps); if (r && r.queued) queued = true; }
      setSave(queued ? "● Saved on this device — will sync" : "✓ Saved " + new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    } catch (e) { showBanner("Couldn't save — " + e.message + " (reloading from Notion)", true); setSave(""); await load(true); }
    finally { state.saving--; }
  }

  function renameUpdates(t, newName, map) {
    map.set(t.id, Object.assign(map.get(t.id) || {}, { task: newName }));
    state.tasks.forEach((x) => { if (x.id === t.id) return; const u = {}; if (x.parent === t.task) u.parent = newName; if (x.dependsOn === t.task) u.dependsOn = newName; if (Object.keys(u).length) map.set(x.id, Object.assign(map.get(x.id) || {}, u)); });
  }

  function parsePred(raw, t) {
    const M = state.model, links = [], can = state.caps.predecessors; let downgraded = false;
    for (const part of raw.split(/[;,]/).map((s) => s.trim()).filter(Boolean)) {
      const m = /^(\d+)\s*(FS|SS|FF|SF)?\s*([+-]\s*\d+)?\s*d?$/i.exec(part); let p, type = "FS", lag = 0;
      if (m) { p = M.flat[parseInt(m[1], 10) - 1]; if (!p) return { error: "There's no row " + m[1] + "." }; if (can) { if (m[2]) type = m[2].toUpperCase(); if (m[3]) lag = parseInt(m[3].replace(/\s/g, ""), 10); } else if (m[2] || m[3]) downgraded = true; }
      else { p = M.byName.get(part); if (!p) return { error: 'No task named "' + part + '".' }; }
      if (p === t) return { error: "A task can't depend on itself." };
      if (links.some((L) => L.p === p.id)) continue;
      const old = (t._links || []).find((L) => L.p === p.id);
      links.push({ p: p.id, t: type, l: lag, h: old ? old.h : 0 });
    }
    for (const L of links) if (wouldCycle(L.p, t.id)) return { error: "That would create a circular dependency." };
    if (!can && links.length > 1) return { error: "Only one predecessor is possible until the PREDECESSORS field exists in Notion." };
    return { links, downgraded };
  }

  async function applyEdit(id, field, raw, restore) {
    const bail = () => { if (restore) restore(); else render(); };
    const t = byId(id); if (!t) { bail(); return; }
    const M = state.model, upd = {}, map = new Map(), okDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && +s.slice(0, 4) >= 1990 && +s.slice(0, 4) <= 2100;
    if (field === "name") {
      const v = raw.trim(); if (!v || v === t.task) { bail(); return; }
      if (M.byName.has(v)) { showBanner("Another task already has that name — names must be unique because groups link by name.", true); bail(); return; }
      renameUpdates(t, v, map);
    } else if (field === "start") {
      if (!okDate(raw)) { bail(); return; }
      const dur = t.start && t.end ? diffDays(t.end, t.start) : 0; upd.start = raw; upd.end = t.milestone ? raw : addDays(raw, dur);
    } else if (field === "end") {
      if (!okDate(raw)) { bail(); return; }
      let e = raw; if (t.start && e < t.start) e = t.start; upd.end = e; if (t.milestone) upd.start = e;
    } else if (field === "dur") {
      const n = parseInt(raw, 10); if (!(n >= 1) || t.milestone || !t.start) { bail(); return; } upd.end = addDays(t.start, n - 1);
    } else if (field === "pct") {
      let n = parseInt(raw, 10); if (isNaN(n)) { bail(); return; } n = Math.max(0, Math.min(100, n)); upd.percent = n;
      if (n >= 100) upd.status = "Complete"; else if (n > 0 && (t.status === "Not Started" || t.status === "Complete")) upd.status = "In Progress"; else if (n === 0 && t.status === "Complete") upd.status = "Not Started";
    } else if (field === "pred") {
      const r = parsePred(raw, t); if (r.error) { showBanner(r.error, true); bail(); return; }
      if (r.downgraded) toast("Link types and lag need the PREDECESSORS field in Notion, so this was kept as a plain Finish → Start link.", 7000);
      if (JSON.stringify(r.links.map(stripLink)) === JSON.stringify((t._links || []).map(stripLink))) { bail(); return; }
      Object.assign(upd, linkUpdate(t, r.links));
    } else if (field === "res") { if (raw.trim() === (t.assignedTo || "")) { bail(); return; } upd.assignedTo = raw.trim(); }
    else if (field === "status") { if (raw === t.status) { bail(); return; } upd.status = raw; if (raw === "Complete") upd.percent = 100; }
    if (Object.keys(upd).length) map.set(id, Object.assign(map.get(id) || {}, upd));
    if (!map.size) { bail(); return; }
    await commitUpdates(map);
  }

  function startEdit(id, field) {
    const t = byId(id); if (!t) return;
    if (t._summary && field !== "name") return;
    const cellEl = q('.cg-lrow[data-id="' + id + '"] .cg-c[data-f="' + field + '"]'); if (!cellEl) return;
    const type = { name: "text", start: "date", end: "date", dur: "number", pct: "number", pred: "text", res: "text", status: "select" }[field];
    const val = { name: t.task, start: t.start || "", end: t.end || "", dur: t.milestone ? "" : t._dur || "", pct: t._pct || 0, pred: predText(t, state.model), res: t.assignedTo || "", status: t.status }[field];
    const origHtml = cellEl.innerHTML, restore = () => { if (cellEl.isConnected) cellEl.innerHTML = origHtml; };
    cellEl.innerHTML = type === "select"
      ? '<select class="cg-ce">' + ["Not Started", "In Progress", "Complete", "Blocked"].map((s) => "<option" + (s === val ? " selected" : "") + ">" + s + "</option>").join("") + "</select>"
      : '<input class="cg-ce" type="' + type + '" value="' + esc(val) + '"' + (type === "number" ? ' min="0"' : "") + (field === "pred" ? ' placeholder="e.g. 3, 5SS+2"' : "") + ">";
    const inp = cellEl.firstChild; state.editing = { id, field }; inp.focus(); if (inp.select && type !== "date" && type !== "select") inp.select();
    let done = false, timer = null;
    const commit = () => { if (done) return; done = true; clearTimeout(timer); state.editing = null; applyEdit(id, field, inp.value, restore); };
    const cancel = () => { if (done) return; done = true; clearTimeout(timer); state.editing = null; restore(); };
    inp.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); commit(); } else if (e.key === "Escape") { e.preventDefault(); cancel(); } });
    inp.addEventListener("blur", commit);
    if (type === "select") inp.addEventListener("change", commit);
    if (type === "date") inp.addEventListener("change", () => { clearTimeout(timer); timer = setTimeout(commit, 900); });   // picking from the calendar commits; typing waits until you pause
  }

  /* ---------------- structure actions ---------------- */
  const siblingsOf = (t) => (t._parent ? t._parent._kids : state.model.roots);
  function orderUpdates(sibs) {
    const map = new Map(), needs = sibs.some((s, i) => s.sortOrder == null || (i > 0 && s.sortOrder <= sibs[i - 1].sortOrder));
    if (!needs) return map;
    sibs.forEach((s, i) => { const v = (i + 1) * 10; if (s.sortOrder !== v) map.set(s.id, { sortOrder: v }); });
    return map;
  }
  function persistCollapsed() { LSset("collapsed-" + state.projectId, [...state.collapsed]); }
  function toggleCollapse(id) { if (state.collapsed.has(id)) state.collapsed.delete(id); else state.collapsed.add(id); persistCollapsed(); render(); }

  async function addTask(isMs, opts) {
    if (!state.projectId) return;
    const M = state.model, child = opts && opts.childOf ? byId(opts.childOf) : null, s = child || sel();
    let sibs = M.roots, parentName = "", after = s;
    if (child) { sibs = child._kids; parentName = child.task; after = sibs[sibs.length - 1] || null; state.collapsed.delete(child.id); }
    else if (s && s._parent) { sibs = s._parent._kids; parentName = s._parent.task; }
    const upd = new Map(); let order = null;
    if (state.caps.sortOrder) {
      orderUpdates(sibs).forEach((u, id) => { Object.assign(byId(id), u); upd.set(id, u); });
      if (after) { const i = sibs.indexOf(after), next = sibs[i + 1]; order = next ? (after.sortOrder + next.sortOrder) / 2 : after.sortOrder + 10; } else order = 10;
    }
    const anchor = after ? liveEnd(after) : child ? liveStart(child) : null;
    const start = anchor ? (after ? addDays(anchor, 1) : anchor) : todayStr(), name = uniqueName(isMs ? "New milestone" : "New task");
    const payload = { task: name, start, end: start, percent: 0, status: "Not Started", assignedTo: "", dependsOn: "", folder: "" };
    if (state.caps.parent) payload.parent = parentName; if (state.caps.milestone) payload.milestone = !!isMs; if (state.caps.sortOrder) payload.sortOrder = order;
    try {
      setSave("Saving…");
      const r = await A.create(state.projectId, payload, state.caps);
      if (r.queued) setSave("● Saved on this device — will sync");
      state.tasks.push(Object.assign({ id: r.id, links: [], createdTime: new Date().toISOString(), parent: "", milestone: false, sortOrder: null }, payload, { milestone: !!isMs && state.caps.milestone }));
      state.selectedId = r.id; state.pendingEdit = { id: r.id, field: "name" };
      if (upd.size) await commitUpdates(upd, { cascade: false }); else { render(); setSave("✓ Saved"); }
    } catch (e) { showBanner("Couldn't add the task: " + e.message, true); setSave(""); }
  }
  async function indent() {
    const t = sel(); if (!t || !state.caps.parent) return;
    const sibs = siblingsOf(t), i = sibs.indexOf(t); if (i <= 0) return;
    const np = sibs[i - 1]; if (np.milestone) { toast("A milestone can't have sub-tasks."); return; }
    const u = { parent: np.task }; if (state.caps.sortOrder) u.sortOrder = np._kids.reduce((m, k) => Math.max(m, k.sortOrder == null ? 0 : k.sortOrder), 0) + 10;
    state.collapsed.delete(np.id); persistCollapsed();
    await commitUpdates(new Map([[t.id, u]]), { cascade: false });
  }
  async function outdent() {
    const t = sel(); if (!t || !state.caps.parent || !t._parent) return;
    const p = t._parent, u = { parent: p._parent ? p._parent.task : "" };
    if (state.caps.sortOrder) u.sortOrder = (p.sortOrder == null ? (p._idx + 1) * 10 : p.sortOrder) + 0.5;
    await commitUpdates(new Map([[t.id, u]]), { cascade: false });
  }
  async function moveRow(dir) {
    const t = sel(); if (!t || !state.caps.sortOrder) return;
    const sibs = siblingsOf(t), j = sibs.indexOf(t) + dir; if (j < 0 || j >= sibs.length) return;
    const map = orderUpdates(sibs); map.forEach((u, id) => Object.assign(byId(id), u));
    const other = sibs[j], a = t.sortOrder, b = other.sortOrder;
    map.set(t.id, Object.assign(map.get(t.id) || {}, { sortOrder: b })); map.set(other.id, Object.assign(map.get(other.id) || {}, { sortOrder: a }));
    await commitUpdates(map, { cascade: false });
  }
  async function deleteTask(id) {
    const t = byId(id); if (!t) return; const kids = t._kids || [];
    const ok = await askDialog({ title: 'Delete "' + t.task + '"?', message: kids.length ? "Its " + kids.length + " sub-task(s) move up to the top level — they are not deleted." : "This removes the task from the schedule.", okText: "Delete" });
    if (!ok) return;
    try {
      setSave("Saving…"); await A.remove(id, state.caps);
      const map = new Map(); kids.forEach((k) => { k.parent = ""; map.set(k.id, { parent: "" }); });
      state.tasks.forEach((x) => {
        if (x.id === id) return; const all = x._links || [], keep = all.filter((L) => L.p !== id);
        if (keep.length !== all.length || x.dependsOn === t.task) map.set(x.id, Object.assign(map.get(x.id) || {}, linkUpdate(x, keep.map(stripLink))));
      });
      state.tasks = state.tasks.filter((x) => x.id !== id); if (state.selectedId === id) state.selectedId = null;
      if (map.size) await commitUpdates(map, { cascade: false }); else { render(); setSave("✓ Saved"); }
    } catch (e) { showBanner("Couldn't delete: " + e.message, true); setSave(""); }
  }
  function toggleMilestone(id) { const t = byId(id); if (!t) return; const u = { milestone: !t.milestone }; if (u.milestone) u.end = t.start; commitUpdates(new Map([[id, u]])); }
  function toggleComplete(id) { const t = byId(id); if (!t) return; const done = t.percent >= 100 || t.status === "Complete"; commitUpdates(new Map([[id, done ? { percent: 0, status: "Not Started" } : { percent: 100, status: "Complete" }]]), { cascade: false }); }
  function toggleBlocked(id) { const t = byId(id); if (!t) return; commitUpdates(new Map([[id, t.status === "Blocked" ? { status: t.percent > 0 ? "In Progress" : "Not Started" } : { status: "Blocked" }]]), { cascade: false }); }

  async function createLink(fromId, fromSide, toId, toSide) {
    const p = byId(fromId), t = byId(toId); if (!p || !t) return;
    if (t._summary) { toast("Link to one of the group's sub-tasks instead — a group follows its sub-tasks."); return; }
    if (wouldCycle(fromId, toId)) { showBanner("That link would create a loop, so it wasn't added.", true); return; }
    const can = state.caps.predecessors, type = can ? (fromSide === "end" ? "F" : "S") + (toSide === "start" ? "S" : "F") : "FS";
    let links = (t._links || []).map(stripLink); const ex = links.find((L) => L.p === fromId);
    if (ex) { if (can) ex.t = type; } else if (can) links.push({ p: fromId, t: type, l: 0, h: 0 }); else links = [{ p: fromId, t: "FS", l: 0, h: 0 }];
    await commitUpdates(new Map([[toId, linkUpdate(t, links)]]));
    toast(p.task + " → " + t.task + ": " + TYPE_NAMES[type] + (ex ? " (updated)" : " link added") + ". It's a soft link — right-click the arrow to lock or change it.", 6000);
  }

  /* ---------------- dialogs & menus ---------------- */
  function askDialog(o) {
    return new Promise((resolve) => {
      const d = el.dlg, inp = d.querySelector(".cg-din"), ok = d.querySelector("[data-ok]"), cancel = d.querySelector("[data-cancel]");
      d.querySelector(".cg-dtitle").textContent = o.title || ""; d.querySelector(".cg-dmsg").textContent = o.message || "";
      inp.style.display = o.input ? "block" : "none"; if (o.input) { inp.type = o.type || "text"; inp.value = o.value == null ? "" : o.value; }
      ok.textContent = o.okText || "OK"; d.style.display = "flex"; if (o.input) { inp.focus(); inp.select(); } else ok.focus();
      const done = (v) => { d.style.display = "none"; ok.onclick = cancel.onclick = inp.onkeydown = d.onkeydown = null; resolve(v); };
      ok.onclick = () => done(o.input ? inp.value : true); cancel.onclick = () => done(o.input ? null : false);
      inp.onkeydown = (e) => { if (e.key === "Enter") done(inp.value); };
      d.onkeydown = (e) => { if (e.key === "Escape") done(o.input ? null : false); };
    });
  }
  let menuScroll = { x: 0, y: 0 };
  function closeMenu() { el.menu.style.display = "none"; el.menu._items = null; }
  function openMenu(x, y, items) {
    const m = el.menu; m._items = items; menuScroll = { x: el.scroller.scrollLeft, y: el.scroller.scrollTop };
    m.innerHTML = items.map((it, i) => it === "-" ? '<div class="cg-msep"></div>' : '<div class="cg-mi' + (it.disabled ? " dis" : "") + (it.danger ? " danger" : "") + '" data-i="' + i + '"><span class="cg-mchk">' + (it.checked ? "✓" : "") + "</span><span>" + esc(it.label) + "</span>" + (it.hint ? '<span class="cg-mhint">' + esc(it.hint) + "</span>" : "") + "</div>").join("");
    m.style.display = "block";
    const w = m.offsetWidth, h = m.offsetHeight, vw = global.innerWidth, vh = global.innerHeight;
    m.style.left = Math.max(4, Math.min(x, vw - w - 4)) + "px"; m.style.top = Math.max(4, Math.min(y, vh - h - 4)) + "px";
  }
  el.menu.addEventListener("click", (e) => { const mi = e.target.closest(".cg-mi"); if (!mi || mi.classList.contains("dis")) return; const it = el.menu._items && el.menu._items[+mi.dataset.i]; closeMenu(); if (it && it.onClick) it.onClick(); });

  function taskMenu(id, x, y) {
    const t = byId(id); if (!t) return; const c = state.caps, M = state.model, sibs = t._parent ? t._parent._kids : M.roots, idx = sibs.indexOf(t), done = t.percent >= 100 || t.status === "Complete";
    const items = [{ label: "Edit details…", onClick: () => openDetail(id) }, "-",
      { label: "Add task below", onClick: () => { select(id); addTask(false); } },
      { label: "Add milestone below", disabled: !c.milestone, onClick: () => { select(id); addTask(true); } },
      { label: "Add sub-task", disabled: !c.parent || !!t.milestone, onClick: () => addTask(false, { childOf: id }) }, "-"];
    if (!t._summary) items.push({ label: "Milestone", checked: !!t.milestone, disabled: !c.milestone, onClick: () => toggleMilestone(id) }, { label: "Complete (100%)", checked: done, onClick: () => toggleComplete(id) }, { label: "Blocked", checked: t.status === "Blocked", onClick: () => toggleBlocked(id) }, "-");
    else items.push({ label: state.collapsed.has(id) ? "Expand group" : "Collapse group", onClick: () => toggleCollapse(id) }, "-");
    items.push({ label: "Indent →", disabled: !(c.parent && idx > 0), onClick: () => { select(id); indent(); } }, { label: "← Outdent", disabled: !(c.parent && t._parent), onClick: () => { select(id); outdent(); } },
      { label: "Move up", disabled: !(c.sortOrder && idx > 0), onClick: () => { select(id); moveRow(-1); } }, { label: "Move down", disabled: !(c.sortOrder && idx < sibs.length - 1), onClick: () => { select(id); moveRow(1); } }, "-");
    if ((t._links || []).length) items.push({ label: "Clear predecessors", onClick: () => commitUpdates(new Map([[id, linkUpdate(t, [])]]), { cascade: false }) });
    items.push({ label: "Delete…", danger: true, onClick: () => deleteTask(id) });
    openMenu(x, y, items);
  }
  function linkMenu(fromId, toId, x, y) {
    const t = byId(toId), p = byId(fromId); if (!t || !p) return;
    const cur = (t._links || []).find((L) => L.p === fromId); if (!cur) return; const can = state.caps.predecessors;
    const set = (patch) => commitUpdates(new Map([[toId, linkUpdate(t, t._links.map((L) => (L.p === fromId ? Object.assign(stripLink(L), patch) : stripLink(L))))]]));
    const items = [{ label: "Locked — keeps dates in line", checked: !!cur.h, disabled: !can, hint: cur.h ? "locked" : "soft", onClick: () => set({ h: cur.h ? 0 : 1 }) }, "-"];
    ["FS", "SS", "FF", "SF"].forEach((k) => items.push({ label: TYPE_NAMES[k], hint: k, checked: cur.t === k, disabled: !can, onClick: () => set({ t: k }) }));
    items.push("-", { label: "Lag: " + (cur.l > 0 ? "+" : "") + cur.l + " days…", disabled: !can, onClick: async () => { const v = await askDialog({ title: "Lag", message: "Days between the two tasks (negative = overlap).", input: true, type: "number", value: cur.l }); if (v === null) return; const n = parseInt(v, 10); if (!isNaN(n)) set({ l: n }); } }, "-",
      { label: "Delete link", danger: true, onClick: () => commitUpdates(new Map([[toId, linkUpdate(t, t._links.filter((L) => L.p !== fromId).map(stripLink))]]), { cascade: false }) });
    openMenu(x, y, items);
  }
  function columnsMenu(x, y) {
    const items = OPTIONAL_COLS.map((k) => ({ label: COLS.find((z) => z.k === k).t, checked: state.colsVisible.indexOf(k) >= 0, onClick: () => { const s = new Set(state.colsVisible); if (s.has(k)) s.delete(k); else s.add(k); state.colsVisible = OPTIONAL_COLS.filter((z) => s.has(z)); LSset("cols", state.colsVisible); render(); } }));
    items.push("-", { label: "Reset column sizes", onClick: () => { state.colW = {}; LSset("colw", {}); render(); } });
    openMenu(x, y, items);
  }
  function viewMenu(x, y) {
    const tog = (k, label) => ({ label, checked: !!state.view[k], onClick: () => { state.view[k] = !state.view[k]; LSset("view", state.view); render(); } });
    const rowSet = (h, label) => ({ label, checked: ROW === h, onClick: () => setRowH(h) });
    openMenu(x, y, [tog("labels", "Bar labels"), tog("connectors", "Link arrows"), tog("weekends", "Weekend shading"), tog("today", "Today line"), "-",
      rowSet(26, "Row height: Compact"), rowSet(34, "Row height: Normal"), rowSet(44, "Row height: Comfortable"), rowSet(56, "Row height: Large"), "-",
      { label: "Zoom: Day", checked: Math.round(state.px) === 32, onClick: () => setPx(32) }, { label: "Zoom: Week", checked: Math.round(state.px) === 14, onClick: () => setPx(14) }, { label: "Zoom: Month", checked: Math.round(state.px) === 4, onClick: () => setPx(4) }, "-",
      { label: "Locked links enforced", checked: state.auto, onClick: toggleLocks }, { label: "Columns…", onClick: () => columnsMenu(x, y) },
      { label: root.classList.contains("cg-full") ? "Exit full screen" : "Full screen", onClick: toggleFull }, "-", { label: "Reset sizes & view", onClick: resetView }]);
  }
  function contextAt(target, x, y) {
    const hit = target.closest(".cg-lhit"); if (hit) return linkMenu(hit.dataset.from, hit.dataset.to, x, y);
    const bar = target.closest("[data-bar]"); if (bar) { select(bar.dataset.bar); return taskMenu(bar.dataset.bar, x, y); }
    const row = target.closest(".cg-lrow"); if (row) { select(row.dataset.id); return taskMenu(row.dataset.id, x, y); }
    if (target.closest(".cg-lhead")) return columnsMenu(x, y);
    viewMenu(x, y);
  }

  /* ---------------- view settings ---------------- */
  function setPx(v) {
    const M = state.model, sc = el.scroller; let centerDay = null;
    if (M) centerDay = (sc.scrollLeft + (sc.clientWidth - state.leftW) / 2) / M.px;
    state.px = Math.max(3, Math.min(80, v)); LSset("px", Math.round(state.px * 100) / 100);
    render();
    if (centerDay !== null && state.model) sc.scrollLeft = Math.max(0, centerDay * state.model.px - (sc.clientWidth - state.leftW) / 2);
  }
  function setRowH(h) { ROW = h; state.rowH = h; LSset("rowh", h); render(); }
  function toggleLocks() { state.auto = !state.auto; LSset("auto", state.auto); updateToolbar(); toast(state.auto ? "Locked links are enforced." : "Locked links are switched off — nothing will be pushed automatically."); }
  function toggleFull() { root.classList.toggle("cg-full"); setTimeout(render, 0); }
  function resetView() {
    state.colW = {}; state.colsVisible = narrow ? ["pct"] : ["wbs", "start", "end", "dur", "pct", "pred"]; state.view = { labels: true, connectors: true, weekends: true, today: true };
    state.px = 32; state.leftW = narrow ? 190 : 620; ROW = state.rowH = touch ? 40 : 34;
    ["colw", "cols", "view", "px", "leftw", "rowh"].forEach((k) => { try { localStorage.removeItem(prefix + k); } catch (e) {} });
    render();
  }
  function scrollToToday(quiet) {
    const M = state.model; if (!M) return; const d = diffDays(todayStr(), M.range.min), sc = el.scroller;
    if (d < 0 || d > M.range.days) { if (!quiet) toast("Today is outside this project's date range — scroll to find your tasks."); else sc.scrollLeft = 0; return; }
    sc.scrollLeft = Math.max(0, d * M.px - (sc.clientWidth - state.leftW) / 2);
  }

  /* ---------------- details panel ---------------- */
  const P = (k) => q('[data-pf="' + k + '"]');
  function renderPanelLinks() {
    const id = state.panelId, can = state.caps.predecessors, used = new Set(state.panelLinks.map((L) => L.p));
    q(".cg-plinks").innerHTML = state.panelLinks.map((L, i) => { const p = byId(L.p); return '<div class="cg-prow" data-i="' + i + '"><span class="pn" title="' + esc(p ? p.task : "?") + '">' + esc(p ? p.task : "(deleted task)") + '</span><select data-lf="t"' + (can ? "" : " disabled") + ">" + ["FS", "SS", "FF", "SF"].map((k) => "<option" + (k === L.t ? " selected" : "") + ">" + k + "</option>").join("") + '</select><input type="number" data-lf="l" value="' + L.l + '" title="Lag in days"' + (can ? "" : " disabled") + '><label title="Locked: keeps dates in line"><input type="checkbox" data-lf="h"' + (L.h ? " checked" : "") + (can ? "" : " disabled") + '>🔒</label><button data-ldel title="Remove">×</button></div>'; }).join("");
    q(".cg-padd").innerHTML = '<option value="">+ Add predecessor…</option>' + state.tasks.filter((x) => x.id !== id && !used.has(x.id)).map((x) => '<option value="' + x.id + '">' + esc(x.task) + "</option>").join("");
  }
  function openDetail(id) {
    const t = byId(id); if (!t) return; select(id); state.panelId = id; closeMenu();
    q(".cg-ptitle").textContent = t._summary ? "Group details" : t.milestone ? "Milestone details" : "Task details";
    P("task").value = t.task; P("start").value = t.start || ""; P("end").value = t.end || ""; P("percent").value = t.percent == null ? 0 : t.percent;
    P("status").value = t.status || "Not Started"; P("assignedTo").value = t.assignedTo || ""; P("folder").value = t.folder || "";
    ["start", "end", "percent"].forEach((k) => (P(k).disabled = !!t._summary));
    const others = state.tasks.filter((x) => x.id !== id), desc = descendantIds(t);
    P("parent").innerHTML = '<option value="">(top level)</option>' + others.filter((x) => !desc.has(x.id) && !x.milestone).map((x) => "<option>" + esc(x.task) + "</option>").join(""); P("parent").value = t.parent || "";
    q('[data-pw="parent"]').style.display = state.caps.parent ? "block" : "none";
    q('[data-pw="milestone"]').style.display = state.caps.milestone ? "block" : "none"; P("milestone").checked = !!t.milestone;
    q('[data-pw="links"]').style.display = t._summary ? "none" : "block";
    state.panelLinks = (t._links || []).map(stripLink); renderPanelLinks();
    el.panel.classList.add("open"); el.overlay.classList.add("show");
  }
  function closeDetail() { el.panel.classList.remove("open"); el.overlay.classList.remove("show"); state.panelId = null; }
  el.panel.addEventListener("change", (e) => {
    const lf = e.target.dataset.lf, row = e.target.closest(".cg-prow");
    if (lf && row) { const L = state.panelLinks[+row.dataset.i]; if (lf === "t") L.t = e.target.value; else if (lf === "l") L.l = parseInt(e.target.value, 10) || 0; else if (lf === "h") L.h = e.target.checked ? 1 : 0; return; }
    if (e.target.classList.contains("cg-padd") && e.target.value) {
      const pid = e.target.value;
      if (wouldCycle(pid, state.panelId)) { showBanner("That would create a circular dependency.", true); renderPanelLinks(); return; }
      const nl = { p: pid, t: "FS", l: 0, h: 0 }; if (state.caps.predecessors) state.panelLinks.push(nl); else state.panelLinks = [nl];
      renderPanelLinks();
    }
  });
  el.panel.addEventListener("click", (e) => { const d = e.target.closest("[data-ldel]"); if (d) { state.panelLinks.splice(+d.closest(".cg-prow").dataset.i, 1); renderPanelLinks(); } });
  async function saveDetail() {
    const id = state.panelId, t = byId(id); if (!t) return closeDetail();
    const M = state.model, map = new Map(), u = {}, norm = (x) => (x == null ? "" : x);
    const name = P("task").value.trim();
    if (name && name !== t.task) { if (M.byName.has(name)) { showBanner("Another task already has that name.", true); return; } renameUpdates(t, name, map); }
    const cmp = (k, v) => { if (norm(v) !== norm(t[k])) u[k] = v; };
    if (!t._summary) { cmp("start", P("start").value || null); cmp("end", P("end").value || null); const pc = Math.max(0, Math.min(100, parseInt(P("percent").value, 10) || 0)); if (pc !== (t.percent || 0)) u.percent = pc; }
    cmp("status", P("status").value); cmp("assignedTo", P("assignedTo").value); cmp("folder", P("folder").value);
    if (state.caps.parent) cmp("parent", P("parent").value);
    if (state.caps.milestone) { const ms = P("milestone").checked; if (ms !== !!t.milestone) { u.milestone = ms; if (ms && (u.start || t.start)) u.end = u.start || t.start; } }
    if (!t._summary && JSON.stringify(state.panelLinks.map(stripLink)) !== JSON.stringify((t._links || []).map(stripLink))) Object.assign(u, linkUpdate(t, state.panelLinks));
    if (Object.keys(u).length) map.set(t.id, Object.assign(map.get(t.id) || {}, u));
    closeDetail(); if (map.size) await commitUpdates(map);
  }

  /* ---------------- pointer interactions ---------------- */
  function startBarDrag(e, bar, t, mode) {
    e.preventDefault(); try { bar.setPointerCapture(e.pointerId); } catch (x) {} state.dragging = true;
    const M = state.model, px = M.px, g = geom(), startX = e.clientX, o0 = diffDays(t.start, M.range.min), o1 = diffDays(t.end || t.start, M.range.min);
    const lbl = q('.cg-lbl[data-for="' + t.id + '"]'), tip = el.tip; let moved = false, dd = 0;
    const calc = () => { let a = o0, b = o1; if (mode === "move") { a = o0 + dd; b = o1 + dd; } else if (mode === "right") b = Math.max(o0, o1 + dd); else a = Math.min(o1, o0 + dd); return [a, b]; };
    const dateAt = (o) => addDays(M.range.min, o);
    const move = (ev) => {
      const dx = ev.clientX - startX; if (Math.abs(dx) > 3) moved = true; if (!moved) return;
      dd = Math.round(dx / px); const [a, b] = calc();
      if (t.milestone) { bar.style.left = a * px + px / 2 - g.ms / 2 + "px"; if (lbl) lbl.style.left = a * px + px / 2 + g.ms / 2 + 8 + "px"; }
      else { const w = Math.max(px * 0.6, (b - a + 1) * px); bar.style.left = a * px + "px"; bar.style.width = w + "px"; if (lbl) lbl.style.left = a * px + w + 6 + "px"; }
      tip.style.display = "block"; tip.style.left = ev.clientX + 14 + "px"; tip.style.top = ev.clientY + 16 + "px";
      tip.textContent = t.milestone ? shortDate(dateAt(a)) : shortDate(dateAt(a)) + " – " + shortDate(dateAt(b)) + "  ·  " + (b - a + 1) + "d";
    };
    const up = () => {
      bar.removeEventListener("pointermove", move); bar.removeEventListener("pointerup", up); bar.removeEventListener("pointercancel", up);
      state.dragging = false;
      tip.style.display = "none"; try { bar.releasePointerCapture(e.pointerId); } catch (x) {}
      if (!moved) return; const [a, b] = calc(); commitUpdates(new Map([[t.id, { start: dateAt(a), end: dateAt(b) }]]));
    };
    bar.addEventListener("pointermove", move); bar.addEventListener("pointerup", up); bar.addEventListener("pointercancel", up);
  }

  function startConnect(e, fromId, side, h) {
    e.preventDefault(); e.stopPropagation();
    const svg = q(".cg-dep"), cvR = () => el.canvas.getBoundingClientRect(), fromBar = h.closest("[data-bar]"), fr = fromBar.getBoundingClientRect(), c0 = cvR();
    const sx = (side === "end" ? fr.right : fr.left) - c0.left, sy = fr.top + fr.height / 2 - c0.top;
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path"); path.setAttribute("class", "cg-rubber"); svg.appendChild(path);
    const clear = () => qa(".cg-target-start,.cg-target-end").forEach((n) => n.classList.remove("cg-target-start", "cg-target-end"));
    let target = null; try { h.setPointerCapture(e.pointerId); } catch (x) {} state.dragging = true;
    const mv = (ev) => {
      const c = cvR(); path.setAttribute("d", "M" + sx + "," + sy + " L" + (ev.clientX - c.left) + "," + (ev.clientY - c.top));
      const under = document.elementFromPoint(ev.clientX, ev.clientY), tb = under && under.closest ? under.closest("[data-bar]") : null; clear();
      if (tb && tb.dataset.bar !== fromId && root.contains(tb)) { const r = tb.getBoundingClientRect(), s = ev.clientX < r.left + r.width / 2 ? "start" : "end"; tb.classList.add("cg-target-" + s); target = { id: tb.dataset.bar, side: s }; } else target = null;
    };
    const up = (ev) => {
      h.removeEventListener("pointermove", mv); h.removeEventListener("pointerup", up); h.removeEventListener("pointercancel", up);
      state.dragging = false;
      try { h.releasePointerCapture(e.pointerId); } catch (x) {} path.remove(); clear();
      if (ev.type !== "pointercancel" && target) createLink(fromId, side, target.id, target.side);
    };
    h.addEventListener("pointermove", mv); h.addEventListener("pointerup", up); h.addEventListener("pointercancel", up);
  }

  const docMove = (fn, end) => { const mv = (ev) => fn(ev), up = () => { document.removeEventListener("pointermove", mv); document.removeEventListener("pointerup", up); end(); }; document.addEventListener("pointermove", mv); document.addEventListener("pointerup", up); };
  function startColResize(e, k) {
    e.preventDefault(); e.stopPropagation(); const c = COLS.find((z) => z.k === k), x0 = e.clientX, w0 = c.flex ? state.leftW : colWidth(c);
    docMove((ev) => { const w = w0 + ev.clientX - x0; if (c.flex) state.leftW = Math.max(touch ? 110 : 280, Math.min(el.scroller.clientWidth - 70, Math.round(w))); else state.colW[k] = Math.max(30, Math.min(320, Math.round(w))); applyVars(); }, () => { LSset("colw", state.colW); LSset("leftw", state.leftW); });
  }
  function startRowResize(e) {
    e.preventDefault(); e.stopPropagation(); const y0 = e.clientY, h0 = ROW; let raf = 0;
    docMove((ev) => { ROW = Math.max(22, Math.min(72, Math.round(h0 + ev.clientY - y0))); state.rowH = ROW; applyVars(); if (!raf) raf = requestAnimationFrame(() => { raf = 0; render(); }); }, () => { LSset("rowh", ROW); render(); });
  }

  /* ---------------- wiring ---------------- */
  const ACTIONS = {
    add: () => addTask(false), ms: () => addTask(true), indent, outdent, up: () => moveRow(-1), down: () => moveRow(1),
    del: () => state.selectedId && deleteTask(state.selectedId), zoomout: () => setPx(state.px / 1.25), zoomin: () => setPx(state.px * 1.25),
    today: () => scrollToToday(false), locks: toggleLocks, full: toggleFull,
    collapse: () => { state.model.flat.forEach((t) => { if (t._summary) state.collapsed.add(t.id); }); persistCollapsed(); render(); },
    expand: () => { state.collapsed.clear(); persistCollapsed(); render(); },
  };
  el.toolbar.addEventListener("click", (e) => {
    const b = e.target.closest("button"); if (!b) return;
    if (b.dataset.zoom) { setPx(+b.dataset.zoom); return; }
    const a = b.dataset.act; if (a === "view") { const r = b.getBoundingClientRect(); viewMenu(r.left, r.bottom + 2); return; }
    if (ACTIONS[a]) ACTIONS[a]();
  });
  qa(".cg-tab").forEach((b) => b.addEventListener("click", () => {
    state.tab = b.dataset.tab; qa(".cg-tab").forEach((x) => x.classList.toggle("on", x === b));
    el.gantt.style.display = state.tab === "gantt" ? "flex" : "none"; el.help.style.display = state.tab === "help" ? "block" : "none";
    el.toolbar.style.display = state.tab === "gantt" ? "" : "none"; el.banner.style.display = state.tab === "gantt" ? "" : "none"; closeMenu(); closeDetail();
    if (state.tab === "gantt") render();
  }));
  el.lrows.addEventListener("click", (e) => {
    const row = e.target.closest(".cg-lrow"); if (!row) return; const id = row.dataset.id;
    if (e.target.closest("[data-rowrs]")) return;
    if (e.target.closest("[data-tg]")) { toggleCollapse(id); return; }
    if (e.target.closest(".cg-c.n")) { openDetail(id); return; }
    const c = e.target.closest(".cg-c[data-f]");
    if (state.selectedId === id && c && !e.target.closest(".cg-ce")) { startEdit(id, c.dataset.f); return; }
    select(id);
  });
  root.addEventListener("pointerdown", (e) => {
    const cr = e.target.closest("[data-colrs]"); if (cr && e.button === 0) { startColResize(e, cr.dataset.colrs); return; }
    const rr = e.target.closest("[data-rowrs]"); if (rr && e.button === 0) { startRowResize(e); return; }
    if (e.target.closest(".cg-split") && e.button === 0) { startColResize(e, "name"); return; }
  });
  el.canvas.addEventListener("pointerdown", (e) => {
    const bar = e.target.closest("[data-bar]"); if (!bar) return;
    const id = bar.dataset.bar, t = byId(id); if (!t) return; select(id);
    if (e.button !== undefined && e.button !== 0) return;
    const lh = e.target.closest("[data-lh]"); if (lh) { startConnect(e, id, lh.dataset.lh, lh); return; }
    if (t._summary) return;
    const mode = e.target.classList.contains("cg-h") ? (e.target.classList.contains("l") ? "left" : "right") : "move";
    if (t.milestone && mode !== "move") return;
    startBarDrag(e, bar, t, mode);
  });
  el.canvas.addEventListener("dblclick", (e) => { const b = e.target.closest("[data-bar]"); if (b) openDetail(b.dataset.bar); });
  q('[data-p="save"]').addEventListener("click", saveDetail); q('[data-p="cancel"]').addEventListener("click", closeDetail); el.overlay.addEventListener("click", closeDetail);
  q('[data-p="delete"]').addEventListener("click", () => { const id = state.panelId; closeDetail(); if (id) deleteTask(id); });
  el.scroller.addEventListener("wheel", (e) => { if (!(e.ctrlKey || e.metaKey)) return; e.preventDefault(); setPx(state.px * (e.deltaY < 0 ? 1.15 : 1 / 1.15)); }, { passive: false });
  el.scroller.addEventListener("scroll", () => { if (el.menu.style.display === "block" && Date.now() - lastRenderAt > 250 && (Math.abs(el.scroller.scrollLeft - menuScroll.x) > 12 || Math.abs(el.scroller.scrollTop - menuScroll.y) > 12)) closeMenu(); });   // late/automatic scroll events must not close it — only really moving the chart does

  let lastLongPress = 0, lp = null;
  const cancelLp = () => { if (lp) { clearTimeout(lp.timer); lp = null; } };
  root.addEventListener("pointerdown", (e) => {
    if (e.pointerType !== "touch" || state.tab !== "gantt") return;
    if (e.target.closest(".cg-panel,.cg-dlg,.cg-menu,.cg-toolbar,.cg-tabs,input,select,textarea,.cg-lh,.cg-h,[data-colrs],[data-rowrs],.cg-split")) return;
    const x0 = e.clientX, y0 = e.clientY, tgt = e.target;
    lp = { x0, y0, timer: setTimeout(() => { lastLongPress = Date.now(); lp = null; contextAt(tgt, x0, y0); }, 520) };
  }, true);
  root.addEventListener("pointermove", (e) => { if (lp && Math.hypot(e.clientX - lp.x0, e.clientY - lp.y0) > 9) cancelLp(); }, true);
  root.addEventListener("pointerup", cancelLp, true); root.addEventListener("pointercancel", cancelLp, true);
  root.addEventListener("contextmenu", (e) => {
    if (state.tab !== "gantt" || e.target.closest("input,textarea,select,.cg-panel,.cg-dlg,.cg-menu,.cg-toolbar,.cg-tabs")) return;
    e.preventDefault(); if (Date.now() - lastLongPress < 800) return; contextAt(e.target, e.clientX, e.clientY);
  });
  const onDocDown = (e) => { if (!el.menu.contains(e.target)) closeMenu(); };
  const onKey = (e) => { if (e.key === "Escape") { closeMenu(); if (state.panelId) closeDetail(); } };
  const onResize = () => { if (state.model && state.tab === "gantt") render(); };
  document.addEventListener("pointerdown", onDocDown, true); document.addEventListener("keydown", onKey); global.addEventListener("resize", onResize);

  /* ---------------- loading & public API ---------------- */
  async function load(keepScroll) {
    if (!state.projectId) { render(); return; }
    try {
      const r = await A.load(state.projectId); if (destroyed) return;
      const snap = JSON.stringify([r.tasks, r.capabilities]), same = keepScroll && snap === state.lastSnap;   // a background refresh that finds nothing new redraws nothing
      state.lastSnap = snap;
      if (!same) {
        state.tasks = r.tasks; state.caps = Object.assign({ parent: false, milestone: false, sortOrder: false, predecessors: false }, r.capabilities);
        state.collapsed = new Set(LS("collapsed-" + state.projectId, []));
        if (!byId(state.selectedId)) state.selectedId = null;
      }
      hideBanner();
      const missing = []; if (!state.caps.parent) missing.push("PARENT TASK (Text)"); if (!state.caps.milestone) missing.push("MILESTONE (Checkbox)"); if (!state.caps.sortOrder) missing.push("SORT ORDER (Number)"); if (!state.caps.predecessors) missing.push("PREDECESSORS (Text)");
      if (missing.length) showBanner("Some features are off until Schedule Tasks//DB in Notion has: " + missing.join(", ") + ". Add them, then reload.", "info");
      if (r.offline) showBanner("Offline — showing the copy saved on this device" + (r.cachedAt ? " (" + new Date(r.cachedAt).toLocaleString([], { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }) + ")" : "") + ". Your changes are kept here and sent automatically when you're back online.", "info");
      if (!same) render(); if (!keepScroll) scrollToToday(true);
    } catch (e) { showBanner("Couldn't load the schedule: " + e.message, true); }
  }
  /* ---------------- offline / sync ---------------- */
  const unsubs = []; let pollTimer = null, refreshTimer = null;
  function renderSync() {
    const b = q(".cg-sync"); if (!A.status) { b.style.display = "none"; return; }
    const s = A.status(); b.style.display = "";
    const tm = (iso) => { try { return new Date(iso).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }); } catch (e) { return ""; } };
    b.className = "cg-sync" + (s.state === "offline" ? " off" : s.state === "syncing" || s.state === "pending" ? " busy" : " ok");
    b.textContent = s.state === "offline" ? "● Offline" + (s.pending ? " · " + s.pending + " waiting" : "") : s.state === "syncing" ? "↻ Syncing…" : s.state === "pending" ? "↻ " + s.pending + " waiting" : "✓ Synced" + (s.lastSynced ? " " + tm(s.lastSynced) : "");
    b.title = s.state === "offline" ? "No connection. Your changes are saved on this device and are sent automatically when you're back online. Tap to try now." : "Tap to sync now.";
    if (A.takeDropped) { const d = A.takeDropped(); if (d.length) toast(d.length + " change" + (d.length > 1 ? "s" : "") + " couldn't be applied (the task may have been deleted on another device) and " + (d.length > 1 ? "were" : "was") + " skipped.", 9000); }
  }
  function refreshIfIdle() {          // pull in changes made elsewhere — but never while you're in the middle of something
    if (destroyed) return;
    if (state.editing || state.panelId || state.dragging || state.saving > 0 || el.menu.style.display === "block" || state.tab !== "gantt") { clearTimeout(refreshTimer); refreshTimer = setTimeout(refreshIfIdle, 2500); return; }
    load(true);
  }
  if (A.onChange) { unsubs.push(A.onChange(renderSync)); renderSync(); }
  if (A.onSynced) unsubs.push(A.onSynced(refreshIfIdle));
  q(".cg-sync").addEventListener("click", async () => { if (A.syncNow) { await A.syncNow(); refreshIfIdle(); } });
  const onVis = () => { if (!document.hidden && A.status) refreshIfIdle(); };
  document.addEventListener("visibilitychange", onVis);
  if (A.status) pollTimer = setInterval(() => { if (!document.hidden) refreshIfIdle(); }, 45000);

  applyVars(); updateToolbar();
  return {
    state, el, root, showBanner, toast,
    load: (projectId) => { if (projectId !== undefined) { state.projectId = projectId; state.selectedId = null; } return load(); },
    reload: () => load(true),
    destroy() { destroyed = true; cancelLp(); unsubs.forEach((f) => f()); clearInterval(pollTimer); clearTimeout(refreshTimer); document.removeEventListener("visibilitychange", onVis); document.removeEventListener("pointerdown", onDocDown, true); document.removeEventListener("keydown", onKey); global.removeEventListener("resize", onResize); root.innerHTML = ""; root.classList.remove("cg", "cg-touch", "cg-full"); },
  };
}
global.GanttEngine = { create, version: "2.0" };
})(typeof window !== "undefined" ? window : globalThis);
