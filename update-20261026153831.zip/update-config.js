/* Where the app looks for new versions of itself.
   One update path (2026-10-21): the GitHub repo jowin-ui/celestial-command-center publishes to Cloudflare,
   and publish-update.bat puts the phone's update in www/updates there. One push updates every device.
   (Before this it was GitHub Pages: https://jowin-ui.github.io/command-updates — no longer used.) */
window.UPDATE_CONFIG = {
  baseUrl: "https://celestial-command-center.kerwin-8fe.workers.dev/updates"
};
