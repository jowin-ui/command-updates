/* gantt-notion.js — shared by the desktop server (Node) and the phone app (browser).
   One place that knows how Gantt tasks map to/from Notion properties, so both stay identical. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.GanttNotion = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const DS = { PROJECTS: "2d9e16c9-632e-8085-9b55-d88d9b02edba", SCHEDULE: "cb5c0781-5bc7-4974-8e24-8036b15a2d62" };
  const TYPES = ["FS", "SS", "FF", "SF"];
  const MAX_LINKS_JSON = 1900;

  // Links live on the SUCCESSOR task: [{p: predecessorPageId, t: "FS", l: lagDays, h: 1 if locked}]
  function parseLinks(text) {
    if (!text) return [];
    try {
      const a = JSON.parse(text);
      if (!Array.isArray(a)) return [];
      return a.filter((x) => x && typeof x.p === "string").map((x) => ({
        p: x.p, t: TYPES.indexOf(x.t) >= 0 ? x.t : "FS", l: Number.isFinite(+x.l) ? Math.trunc(+x.l) : 0, h: x.h ? 1 : 0,
      }));
    } catch (e) { return []; }
  }
  function serializeLinks(links) {
    return JSON.stringify((links || []).map((x) => ({ p: x.p, t: x.t, l: x.l || 0, h: x.h ? 1 : 0 })));
  }
  function capsFromSchema(p) {
    p = p || {};
    return {
      parent: !!p["PARENT TASK"] && p["PARENT TASK"].type === "rich_text",
      milestone: !!p["MILESTONE"] && p["MILESTONE"].type === "checkbox",
      sortOrder: !!p["SORT ORDER"] && p["SORT ORDER"].type === "number",
      predecessors: !!p["PREDECESSORS"] && p["PREDECESSORS"].type === "rich_text",
    };
  }
  const text = (x) => (x && x.rich_text ? x.rich_text.map((t) => t.plain_text).join("") : "");
  function mapTask(page) {
    const p = page.properties || {};
    const d = (x) => (x && x.date && x.date.start ? x.date.start.slice(0, 10) : null);
    return {
      id: page.id,
      task: p.TASK && p.TASK.title ? p.TASK.title.map((t) => t.plain_text).join("") : "",
      start: d(p["START DATE"]), end: d(p["END DATE"]),
      percent: p["PERCENT COMPLETE"] && p["PERCENT COMPLETE"].number != null ? p["PERCENT COMPLETE"].number : 0,
      status: p.STATUS && p.STATUS.select ? p.STATUS.select.name : "Not Started",
      assignedTo: text(p["ASSIGNED TO"]),
      dependsOn: text(p["DEPENDS ON (TASK NAME)"]),            // legacy single predecessor, by name (kept in sync as a mirror)
      folder: (p["LINKED FOLDER"] && p["LINKED FOLDER"].url) || "",
      parent: text(p["PARENT TASK"]),
      milestone: !!(p["MILESTONE"] && p["MILESTONE"].checkbox),
      sortOrder: p["SORT ORDER"] && p["SORT ORDER"].number != null ? p["SORT ORDER"].number : null,
      links: parseLinks(text(p["PREDECESSORS"])),
      createdTime: page.created_time || "",
    };
  }
  const rt = (s) => ({ rich_text: [{ text: { content: String(s == null ? "" : s).slice(0, 2000) } }] });
  // UI field names -> Notion properties. Optional fields are only written if the database has them.
  function buildProps(body, caps) {
    const props = {}, ignored = [];
    if (body.task !== undefined) props.TASK = { title: [{ text: { content: String(body.task).slice(0, 2000) } }] };
    if (body.start !== undefined) props["START DATE"] = { date: body.start ? { start: body.start } : null };
    if (body.end !== undefined) props["END DATE"] = { date: body.end ? { start: body.end } : null };
    if (body.percent !== undefined) props["PERCENT COMPLETE"] = { number: Number(body.percent) || 0 };
    if (body.status) props.STATUS = { select: { name: body.status } };
    if (body.assignedTo !== undefined) props["ASSIGNED TO"] = rt(body.assignedTo);
    if (body.dependsOn !== undefined) props["DEPENDS ON (TASK NAME)"] = rt(body.dependsOn);
    if (body.folder !== undefined) props["LINKED FOLDER"] = { url: body.folder || null };
    if (body.parent !== undefined) { if (caps.parent) props["PARENT TASK"] = rt(body.parent); else ignored.push("parent"); }
    if (body.milestone !== undefined) { if (caps.milestone) props["MILESTONE"] = { checkbox: !!body.milestone }; else ignored.push("milestone"); }
    if (body.sortOrder !== undefined) { if (caps.sortOrder) props["SORT ORDER"] = { number: body.sortOrder === null ? null : Number(body.sortOrder) }; else ignored.push("sortOrder"); }
    if (body.links !== undefined) {
      if (caps.predecessors) {
        const json = serializeLinks(body.links);
        if (json.length > MAX_LINKS_JSON) { const e = new Error("Too many links on one task (limit about 25)."); e.status = 400; throw e; }
        props["PREDECESSORS"] = rt(body.links.length ? json : "");
      } else ignored.push("links");
    }
    return { props, ignored };
  }
  return { DS, TYPES, parseLinks, serializeLinks, capsFromSchema, mapTask, buildProps };
});
