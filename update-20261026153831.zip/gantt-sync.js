/* gantt-sync.js — makes the Gantt work with no signal.
   Wraps a normal adapter: keeps a copy of each project on the device, saves your edits there instantly,
   and sends them to Notion (in order) whenever a connection is available. Used by the desktop page AND the phone app. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.GanttSync = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const rand = () => Math.random().toString(36).slice(2, 10);
  const memoryStorage = () => { const m = {}; return { getItem: (k) => (k in m ? m[k] : null), setItem: (k, v) => { m[k] = String(v); }, removeItem: (k) => { delete m[k]; } }; };
  // network = no connection / timed out; transient = Notion busy (try again later); rejected = Notion said no (retrying won't help)
  function classify(e) { const s = e && e.status; if (!s) return "network"; if (s === 429 || s === 409 || s >= 500) return "transient"; return "rejected"; }
  function withTimeout(p, ms, label) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error("Timed out" + (label ? " " + label : ""))), ms);
      p.then((v) => { clearTimeout(t); resolve(v); }, (e) => { clearTimeout(t); reject(e); });
    });
  }

  function wrap(inner, opts) {
    opts = opts || {};
    const storage = opts.storage || (typeof localStorage !== "undefined" ? localStorage : memoryStorage());
    const ns = "gsync:" + (opts.key || "default") + ":";
    const T = Object.assign({ patch: 12000, create: 30000, load: 20000, remove: 12000 }, opts.timeouts || {});
    const read = (k, d) => { try { const v = storage.getItem(ns + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
    const write = (k, v) => { try { storage.setItem(ns + k, JSON.stringify(v)); } catch (e) {} };
    let outbox = read("outbox", []), idMap = read("idmap", {}), caps = read("caps", {}), lastSynced = read("lastSynced", null), cachedProjects = read("cachedProjects", []);
    let flushing = false, offline = false, disposed = false, dropped = [];
    const changeCbs = [], syncedCbs = [], now = () => new Date().toISOString();
    const navOffline = () => typeof navigator !== "undefined" && navigator.onLine === false;
    const isTmp = (id) => String(id).indexOf("tmp-") === 0;
    const rid = (id) => idMap[id] || id;
    const persist = () => write("outbox", outbox);

    function status() {
      const off = offline || navOffline();
      return { state: flushing ? "syncing" : outbox.length ? (off ? "offline" : "pending") : off ? "offline" : "synced", pending: outbox.length, lastSynced, offline: off };
    }
    const emit = () => changeCbs.slice().forEach((f) => { try { f(status()); } catch (e) {} });
    const emitSynced = () => syncedCbs.slice().forEach((f) => { try { f(); } catch (e) {} });
    function setOffline(v) { if (offline !== v) { offline = v; emit(); } }
    function markOk() { const was = offline; offline = false; lastSynced = now(); write("lastSynced", lastSynced); if (was) emit(); }

    /* ---- on-device copy of each project (always includes changes that haven't been sent yet) ---- */
    const readCache = (pid) => read("cache:" + pid, null);
    function writeCache(pid, data) { write("cache:" + pid, data); if (cachedProjects.indexOf(pid) < 0) { cachedProjects.push(pid); write("cachedProjects", cachedProjects); } }
    function applyOp(tasks, op) {
      if (op.type === "create") { if (!tasks.some((t) => t.id === op.taskId)) tasks.push(Object.assign({ percent: 0, status: "Not Started", assignedTo: "", dependsOn: "", folder: "", parent: "", milestone: false, sortOrder: null, links: [], createdTime: op.ts }, clone(op.body), { id: op.taskId })); }
      else if (op.type === "patch") { const t = tasks.find((x) => x.id === op.taskId); if (t) Object.assign(t, clone(op.body)); }
      else if (op.type === "remove") { const i = tasks.findIndex((x) => x.id === op.taskId); if (i >= 0) tasks.splice(i, 1); }
    }
    function cacheApply(op) {
      (op.projectId ? [op.projectId] : cachedProjects).forEach((pid) => {
        const c = readCache(pid); if (!c) return;
        if (op.type !== "create" && !c.tasks.some((t) => t.id === op.taskId)) return;
        applyOp(c.tasks, op); writeCache(pid, c);
      });
    }
    function remap(tmp, real) {            // a task created offline just got its real Notion id: fix everything that mentions the old one
      idMap[tmp] = real; write("idmap", idMap);
      const fix = (arr) => (arr || []).forEach((l) => { if (l.p === tmp) l.p = real; });
      outbox.forEach((o) => { if (o.taskId === tmp) o.taskId = real; if (o.body) fix(o.body.links); });
      cachedProjects.forEach((pid) => { const c = readCache(pid); if (!c) return; c.tasks.forEach((t) => { if (t.id === tmp) t.id = real; fix(t.links); }); writeCache(pid, c); });
      persist();
    }
    const fixBody = (b) => { const o = clone(b || {}); if (o.links) o.links.forEach((l) => { l.p = rid(l.p); }); return o; };

    function enqueue(op) {
      if (op.type === "patch") {
        const prior = outbox.find((o) => o.taskId === op.taskId && (o.type === "patch" || o.type === "create"));
        if (prior) { Object.assign(prior.body, clone(op.body)); persist(); return; }                // later edits fold into the waiting one
      } else if (op.type === "remove") {
        if (outbox.some((o) => o.type === "create" && o.taskId === op.taskId)) { outbox = outbox.filter((o) => o.taskId !== op.taskId); persist(); return; }   // never reached Notion: just forget it
        outbox = outbox.filter((o) => !(o.type === "patch" && o.taskId === op.taskId));
      }
      outbox.push(op); persist();
    }
    const canTryNow = () => !outbox.length && !offline && !navOffline() && !flushing;

    async function flush() {
      if (flushing || disposed || !outbox.length) return;
      if (navOffline()) { setOffline(true); return; }
      flushing = true; offline = false; emit(); let sent = 0;
      try {
        while (outbox.length) {
          const op = outbox[0];
          try {
            if (op.type === "create") { const r = await withTimeout(inner.create(op.projectId, op.body, caps), T.create, "adding"); remap(op.taskId, r.id); }
            else if (op.type === "patch") await withTimeout(inner.patch(op.taskId, op.body, caps), T.patch, "saving");
            else await withTimeout(inner.remove(op.taskId, caps), T.remove, "deleting");
            outbox.shift(); persist(); sent++;
          } catch (e) {
            const k = classify(e);
            if (k === "rejected") {         // Notion refused it (e.g. the task was deleted elsewhere): skip it so it can't block everything behind it
              dropped.push({ type: op.type, taskId: op.taskId, message: e.message });
              outbox.shift(); if (op.type === "create") outbox = outbox.filter((o) => o.taskId !== op.taskId); persist(); continue;
            }
            if (k === "network") offline = true;
            break;
          }
        }
      } finally { flushing = false; }
      if (!outbox.length && !offline) { lastSynced = now(); write("lastSynced", lastSynced); }
      emit(); if (sent || dropped.length) emitSynced();
    }

    async function load(projectId) {
      if (outbox.length) await flush();               // send what's waiting first, so the fresh copy already contains it
      try {
        const r = await withTimeout(inner.load(projectId), T.load, "loading");
        const tasks = clone(r.tasks);
        outbox.forEach((o) => { if (o.type === "create" ? o.projectId === projectId : true) applyOp(tasks, o); });
        caps = r.capabilities || caps; write("caps", caps);
        writeCache(projectId, { tasks: clone(tasks), capabilities: r.capabilities, at: now() });
        markOk();
        return { capabilities: r.capabilities, tasks, offline: false, pending: outbox.length };
      } catch (e) {
        if (classify(e) === "rejected") throw e;
        const c = readCache(projectId);
        if (!c) throw new Error("No connection, and this project isn't saved on this device yet. Open it once while you're online.");
        setOffline(classify(e) === "network");
        return { capabilities: c.capabilities, tasks: clone(c.tasks), offline: true, cachedAt: c.at, pending: outbox.length };
      }
    }
    async function create(projectId, body, capsArg) {
      if (capsArg) { caps = capsArg; write("caps", caps); }
      const op = { id: rand(), type: "create", projectId, taskId: "tmp-" + rand(), body: fixBody(body), ts: now() };
      if (canTryNow()) {
        try { const r = await withTimeout(inner.create(projectId, op.body, caps), T.create, "adding"); markOk(); cacheApply({ type: "create", projectId, taskId: r.id, body: op.body, ts: op.ts }); return r; }
        catch (e) { const k = classify(e); if (k === "rejected") throw e; if (k === "network") setOffline(true); }
      }
      enqueue(op); cacheApply(op); emit(); setTimeout(flush, 0);
      return { id: op.taskId, queued: true };
    }
    async function patch(id, body, capsArg) {
      if (capsArg) { caps = capsArg; write("caps", caps); }
      id = rid(id); body = fixBody(body);
      const op = { id: rand(), type: "patch", taskId: id, body: clone(body), ts: now() };
      cacheApply(op);
      if (!isTmp(id) && canTryNow()) {
        try { const r = await withTimeout(inner.patch(id, body, caps), T.patch, "saving"); markOk(); return r; }
        catch (e) { const k = classify(e); if (k === "rejected") throw e; if (k === "network") setOffline(true); }
      }
      enqueue(op); emit(); setTimeout(flush, 0);
      return { ok: true, queued: true };
    }
    async function remove(id, capsArg) {
      if (capsArg) { caps = capsArg; write("caps", caps); }
      id = rid(id); const op = { id: rand(), type: "remove", taskId: id, ts: now() };
      cacheApply(op);
      if (!isTmp(id) && canTryNow()) {
        try { const r = await withTimeout(inner.remove(id, caps), T.remove, "deleting"); markOk(); return r; }
        catch (e) { const k = classify(e); if (k === "rejected") throw e; if (k === "network") setOffline(true); }
      }
      enqueue(op); emit(); setTimeout(flush, 0);
      return { ok: true, queued: true };
    }
    async function projects() {
      if (!inner.projects) return [];
      try { const l = await withTimeout(inner.projects(), T.load, "loading"); write("projects", l); markOk(); return l; }
      catch (e) { if (classify(e) === "rejected") throw e; setOffline(true); const c = read("projects", null); if (c) return c; throw e; }
    }
    async function syncNow() { offline = false; await flush(); emitSynced(); }

    const onChange = (cb) => { changeCbs.push(cb); return () => { const i = changeCbs.indexOf(cb); if (i >= 0) changeCbs.splice(i, 1); }; };
    const onSynced = (cb) => { syncedCbs.push(cb); return () => { const i = syncedCbs.indexOf(cb); if (i >= 0) syncedCbs.splice(i, 1); }; };
    // pick things back up on their own: connection returns, app comes back to the front, or just periodically
    const timers = [], listeners = [];
    const on = (t, ev, fn) => { if (t && t.addEventListener) { t.addEventListener(ev, fn); listeners.push([t, ev, fn]); } };
    if (typeof window !== "undefined" && opts.auto !== false) {
      on(window, "online", () => { offline = false; flush().then(() => { emit(); emitSynced(); }); });
      on(window, "offline", () => setOffline(true));
      on(document, "visibilitychange", () => { if (!document.hidden) { if (outbox.length) flush(); } });
      timers.push(setInterval(() => { if (disposed) return; if (outbox.length) flush(); else if (offline && !navOffline()) emitSynced(); }, opts.retryMs || 15000));
    }
    if (outbox.length && opts.auto !== false) setTimeout(flush, 800);   // changes left over from last time: send them as soon as we can

    return {
      load, create, patch, remove, projects, status, onChange, onSynced, syncNow,
      takeDropped() { const d = dropped; dropped = []; return d; },
      dispose() { disposed = true; timers.forEach(clearInterval); listeners.forEach(([t, ev, fn]) => t.removeEventListener(ev, fn)); },
      _outbox: () => clone(outbox), _flush: flush,
    };
  }
  return { wrap, classify };
});
